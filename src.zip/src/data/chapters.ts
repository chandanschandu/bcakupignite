export const chapters = [
  { id: 1, name: "Fun with Words" },
  { id: 2, name: "Jo Jo Laali (A jogula)" },
  { id: 3, name: "Kamala's First Day at School" },
  { id: 4, name: "Friends" },
  { id: 5, name: "A Little Clock" },
  { id: 6, name: "Let's Play Hide-and-Seek!" },
  { id: 7, name: "Healthy Habits" },
  { id: 8, name: "Four Seasons" },
];
