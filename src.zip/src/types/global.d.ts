// src/types/global.d.ts
interface Window {
  API: any; // Consider replacing 'any' with a more specific type if available
  API_1484_11?: any; // For SCORM 2004 support
}