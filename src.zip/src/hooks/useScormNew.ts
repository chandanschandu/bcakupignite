import { useState, useEffect } from 'react';
import { scorm12Api, scorm2004Api } from '../scorm/ScormAPI';
import { trackPageView, trackCompletion, trackScore } from '../scorm/ScormEventBridge';
import { fetchScormData } from '../services/scormService';

export const useScorm = () => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  // Initialize SCORM connection
  const initialize = async () => {
    try {
      console.log('[SCORM HOOK] Initializing SCORM...');
      
      // Check if APIs are available
      const api12Available = !!(window as any).API;
      const api2004Available = !!(window as any).API_1484_11;
      
      if (!api12Available && !api2004Available) {
        console.warn('[SCORM HOOK] No SCORM API available');
        return false;
      }

      // Initialize the preferred API (SCORM 2004 if available, otherwise 1.2)
      const api = api2004Available ? scorm2004Api : scorm12Api;
      const result = api.Initialize();
      
      if (result === 'true') {
        setIsInitialized(true);
        setIsConnected(true);
        console.log('[SCORM HOOK] SCORM initialized successfully');
        return true;
      } else {
        console.error('[SCORM HOOK] SCORM initialization failed');
        return false;
      }
    } catch (error) {
      console.error('[SCORM HOOK] Error initializing SCORM:', error);
      return false;
    }
  };

  // Set a SCORM value
  const setValue = (element: string, value: string) => {
    try {
      const api = (window as any).API_1484_11 || (window as any).API;
      if (!api) {
        console.warn('[SCORM HOOK] SCORM API not available');
        return false;
      }

      const result = api.SetValue(element, value);
      console.log('[SCORM HOOK] Set value:', element, '=', value, 'Result:', result);
      return result === 'true';
    } catch (error) {
      console.error('[SCORM HOOK] Error setting SCORM value:', error);
      return false;
    }
  };

  // Get a SCORM value
  const getValue = (element: string) => {
    try {
      const api = (window as any).API_1484_11 || (window as any).API;
      if (!api) {
        console.warn('[SCORM HOOK] SCORM API not available');
        return '';
      }

      const result = api.GetValue(element);
      console.log('[SCORM HOOK] Get value:', element, '=', result);
      return result || '';
    } catch (error) {
      console.error('[SCORM HOOK] Error getting SCORM value:', error);
      return '';
    }
  };

  // Commit SCORM data
  const commit = () => {
    try {
      const api = (window as any).API_1484_11 || (window as any).API;
      if (!api) {
        console.warn('[SCORM HOOK] SCORM API not available');
        return false;
      }

      const result = api.Commit();
      console.log('[SCORM HOOK] Commit result:', result);
      return result === 'true';
    } catch (error) {
      console.error('[SCORM HOOK] Error committing SCORM data:', error);
      return false;
    }
  };

  // Terminate SCORM connection
  const terminate = () => {
    try {
      const api = (window as any).API_1484_11 || (window as any).API;
      if (!api) {
        console.warn('[SCORM HOOK] SCORM API not available');
        return false;
      }

      const result = api.Terminate();
      console.log('[SCORM HOOK] Terminate result:', result);
      
      setIsInitialized(false);
      setIsConnected(false);
      return result === 'true';
    } catch (error) {
      console.error('[SCORM HOOK] Error terminating SCORM:', error);
      return false;
    }
  };

  // Track page navigation
  const trackPage = (pageName: string) => {
    trackPageView(pageName);
    setValue('cmi.location', pageName);
  };

  // Track completion status
  const setCompletionStatus = (status: 'completed' | 'incomplete' | 'failed') => {
    trackCompletion(status);
    setValue('cmi.completion_status', status);
  };

  // Track score
  const setScore = (score: number, maxScore: number = 100) => {
    trackScore(score, maxScore);
    setValue('cmi.score.raw', score.toString());
    setValue('cmi.score.max', maxScore.toString());
    setValue('cmi.score.min', '0');
    setValue('cmi.score.scaled', (score / maxScore).toString());
  };

  // Fetch stored progress
  const fetchProgress = async (element?: string) => {
    try {
      const data = await fetchScormData(element);
      return data;
    } catch (error) {
      console.error('[SCORM HOOK] Error fetching progress:', error);
      return null;
    }
  };

  // Auto-initialize on mount
  useEffect(() => {
    initialize();
    
    // Auto-terminate on unmount
    return () => {
      if (isInitialized) {
        terminate();
      }
    };
  }, []);

  return {
    isInitialized,
    isConnected,
    initialize,
    setValue,
    getValue,
    commit,
    terminate,
    trackPage,
    setCompletionStatus,
    setScore,
    fetchProgress
  };
};
