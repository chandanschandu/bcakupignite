// API Configuration - Centralized base URLs for all services

// Environment-based API base URL
export const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://oxford-uat.excelindia.com' 
  : 'https://oxford-uat.excelindia.com';

// Service-specific base URLs
export const API_ENDPOINTS = {
  // Authentication endpoints
  AUTH: {
    LOGIN: `${API_BASE_URL}/login`,
    TOKEN: `${API_BASE_URL}/api/token`,
    LOGOUT: `${API_BASE_URL}/logout`,
    RESET_PASSWORD: `${API_BASE_URL}/reset-password`,
  },
  
  // User management endpoints
  USER: {
    BASE: `${API_BASE_URL}/users`,
    DETAILS: (userId: string) => `${API_BASE_URL}/users/get-user-details/${userId}`,
    UPDATE: `${API_BASE_URL}/users/update-profile`,
    CHANGE_PASSWORD: `${API_BASE_URL}/login/change-password`,
  },
  
  // Content endpoints
  CONTENT: {
    BASE: `${API_BASE_URL}/content`,
    CHAPTERS: (userId: string, planClassId: string) => 
      `${API_BASE_URL}/chapters?userId=${userId}&planClassId=${planClassId}`,
    LESSON_PLANS: `${API_BASE_URL}/lesson-plans`,
    ASSESSMENTS: `${API_BASE_URL}/assessments`,
    RESOURCES: `${API_BASE_URL}/resources`,
  },
  
  // Progress tracking endpoints
  PROGRESS: {
    BASE: `${API_BASE_URL}/progress`,
    TRACK: `${API_BASE_URL}/track-progress`,
    COMPLETION: `${API_BASE_URL}/mark-complete`,
  },
  
  // File upload endpoints
  UPLOAD: {
    PROFILE_IMAGE: `${API_BASE_URL}/upload/profile-image`,
    DOCUMENT: `${API_BASE_URL}/upload/document`,
  },
  
  // External links
  EXTERNAL: {
    ADMIN_LOGIN: 'https://oxford-uat.excelindia.com/Oxford-ignite/School/Home.aspx',
    SUPPORT: `${API_BASE_URL}/support`,
    HELP: `${API_BASE_URL}/help`,
  }
} as const;

// Page-specific base URLs for routing
export const PAGE_BASE_URLS = {
  LOGIN: '/login',
  PROFILE_SETTINGS: '/profile-settings',
  PRELOGIN: '/prelogin',
  CHAPTERS: '/chapters',
  DASHBOARD: '/dashboard',
  BOOK_READER: '/book-reader',
  ADMIN: 'https://oxford-uat.excelindia.com/Oxford-ignite/School/Home.aspx',
} as const;

// Default configurations
export const DEFAULT_CONFIG = {
  API_TIMEOUT: 30000, // 30 seconds
  RETRY_ATTEMPTS: 3,
  CACHE_DURATION: 30 * 60 * 1000, // 30 minutes in milliseconds
  SCROLL_THRESHOLD: 100,
  ZOOM_MIN: 0.5,
  ZOOM_MAX: 3.0,
  ZOOM_STEP: 0.25,
} as const;

// Export main API base URL for backward compatibility
export default API_BASE_URL;
