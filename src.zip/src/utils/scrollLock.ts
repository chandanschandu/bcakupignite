/**
 * Utility functions for managing body scroll locking
 * Prevents background scrolling when modals/dropdowns are open
 */

let scrollY = 0;
let lockCount = 0;

/**
 * Lock body scroll - prevents background scrolling
 * Can be called multiple times, will only unlock when called the same number of times
 */
export const lockBodyScroll = () => {
  lockCount++;
  
  if (lockCount === 1) {
    // Store current scroll position
    scrollY = window.scrollY;
    
    // Lock body scroll - use overflow hidden only, avoid position:fixed 
    // which causes issues with internal scrolling on mobile
    document.body.style.overflow = 'hidden';
    document.body.style.overscrollBehavior = 'none';
  }
};

/**
 * Unlock body scroll - restores background scrolling
 * Must be called the same number of times as lockBodyScroll
 */
export const unlockBodyScroll = () => {
  lockCount--;
  
  if (lockCount <= 0) {
    lockCount = 0;
    
    // Restore body scroll
    document.body.style.overflow = '';
    document.body.style.overscrollBehavior = '';
    document.body.style.touchAction = '';
    
    // Restore scroll position
    window.scrollTo(0, scrollY);
  }
};

/**
 * Check if body scroll is currently locked
 */
export const isBodyScrollLocked = () => lockCount > 0;

/**
 * Force unlock body scroll (emergency cleanup)
 */
export const forceUnlockBodyScroll = () => {
  lockCount = 0;
  document.body.style.overflow = '';
  document.body.style.overscrollBehavior = '';
  document.body.style.touchAction = '';
};
