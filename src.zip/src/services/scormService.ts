import { getApiBaseUrl } from '@/utils/config';
import { ScormProgressData } from '../scorm/scormTypes';

// Debouncing utility to prevent multiple API calls
const apiCallCache = new Map<string, { timestamp: number; value: string }>();
const DEBOUNCE_DELAY = 300; // Reduced to 300ms for better responsiveness

// Rate limiting to prevent excessive API calls
const RATE_LIMIT = {
  maxCallsPerMinute: 60, // Increased from 30 to allow more frequent updates
  callHistory: [] as number[]
};

const isRateLimited = (): boolean => {
  const now = Date.now();
  const oneMinuteAgo = now - 60000;
  
  // Clean old calls
  RATE_LIMIT.callHistory = RATE_LIMIT.callHistory.filter(time => time > oneMinuteAgo);
  
  // Check if we've exceeded the limit
  if (RATE_LIMIT.callHistory.length >= RATE_LIMIT.maxCallsPerMinute) {
    console.warn('[SCORM] Rate limit exceeded, skipping API call');
    return true;
  }
  
  // Add this call to history
  RATE_LIMIT.callHistory.push(now);
  return false;
};

const shouldMakeApiCall = (key: string, value: string): boolean => {
  const cached = apiCallCache.get(key);
  const now = Date.now();
  
  if (cached && cached.value === value && (now - cached.timestamp) < DEBOUNCE_DELAY) {
    console.log('[SCORM] Debouncing duplicate call:', key);
    return false; // Skip duplicate call within debounce period
  }
  
  // Check rate limit
  if (isRateLimited()) {
    return false;
  }
  
  apiCallCache.set(key, { timestamp: now, value });
  return true;
};

// Filter out meaningless style changes - ENHANCED VERSION
const shouldTrackStyleChange = (elementData: any): boolean => {
  console.log('[SCORM] Checking style change:', elementData);
  
  // Skip loading indicators and progress bars
  if (elementData.text && elementData.text.includes('Loading:')) {
    console.log('[SCORM] Skipping loading indicator');
    return false;
  }
  
  // Skip empty or whitespace-only text
  if (!elementData.text || elementData.text.trim().length === 0) {
    console.log('[SCORM] Skipping empty text');
    return false;
  }
  
  // Skip elements with only transition classes
  if (elementData.classes === 'fadeOut' || 
      elementData.classes === 'transitioning') {
    console.log('[SCORM] Skipping transition classes');
    return false;
  }
  
  // ALLOW meaningful interactions - much more permissive now
  const hasMeaningfulContent = 
    elementData.text.includes('Fun Words') || 
    elementData.text.includes('Chapter') ||
    elementData.text.includes('Lesson') ||
    (elementData.color && elementData.color !== 'default' && elementData.color !== 'rgb(0, 0, 0)') ||
    (elementData.backgroundColor && elementData.backgroundColor !== 'default' && elementData.backgroundColor !== 'rgba(0, 0, 0, )' && elementData.backgroundColor !== 'transparent') ||
    (elementData.fontWeight && elementData.fontWeight !== 'default') ||
    (elementData.type === 'highlight') ||
    (elementData.type === 'text_coloring') ||
    (elementData.type === 'comment_input') ||
    (elementData.type === 'comment_final');
  
  if (hasMeaningfulContent) {
    console.log('[SCORM] Allowing meaningful style change:', elementData.type || 'unknown');
    return true;
  }
  
  // Default to allowing updates (less restrictive)
  console.log('[SCORM] Allowing style change by default');
  return true;
};

// Enhanced SCORM service wrapper - Standalone version
export const useScormService = () => {
  // Direct API calls without React context dependency
  const setScormValue = (key: string, value: any) => {
    console.log('[SCORM SERVICE] Setting value:', key, value);
    // Direct call to send data
    sendScormData(key, value);
  };

  const getScormValue = (key: string): any => {
    console.log('[SCORM SERVICE] Getting value:', key);
    // This would need to be implemented to fetch from backend
    return null;
  };

  const commitScormData = () => {
    console.log('[SCORM SERVICE] Committing data');
    return true;
  };

  const setScore = (score: number) => {
    // Set SCORM score values
    setScormValue('cmi.core.score.raw', score.toString());
    setScormValue('cmi.core.score.min', '0');
    setScormValue('cmi.core.score.max', '100');
    commitScormData();
    
    // Only send to backend API if different and not debounced
    if (shouldMakeApiCall('cmi.core.score.raw', score.toString())) {
      sendScormData('cmi.core.score.raw', score.toString());
    }
  };

  const setStatus = (status: 'incomplete' | 'completed' | 'passed' | 'failed') => {
    setScormValue('cmi.core.lesson_status', status);
    commitScormData();
    
    // Only send to backend API if different and not debounced
    if (shouldMakeApiCall('cmi.core.lesson_status', status)) {
      sendScormData('cmi.core.lesson_status', status);
    }
  };

  const getSuspendData = () => {
    const data = getScormValue('cmi.suspend_data');
    return data ? JSON.parse(data) : {};
  };

  const setSuspendData = (data: any) => {
    const jsonData = JSON.stringify(data);
    setScormValue('cmi.suspend_data', jsonData);
    commitScormData();
    
    // Only send to backend API if different and not debounced
    if (shouldMakeApiCall('cmi.suspend_data', jsonData)) {
      sendScormData('cmi.suspend_data', jsonData);
    }
  };

  const getProgress = () => getScormValue('cmi.core.progress_measure');
  
  const setProgress = (progress: number) => {
    setScormValue('cmi.core.progress_measure', progress.toString());
    commitScormData();
    
    // Only send to backend API if different and not debounced
    if (shouldMakeApiCall('cmi.core.progress_measure', progress.toString())) {
      sendScormData('cmi.core.progress_measure', progress.toString());
    }
  };

  const setBookmark = (location: string) => {
    setScormValue('cmi.core.lesson_location', location);
    commitScormData();
    
    // Only send to backend API if different and not debounced
    if (shouldMakeApiCall('cmi.core.lesson_location', location)) {
      sendScormData('cmi.core.lesson_location', location);
    }
  };

  const setStudentName = (name: string) => {
    setScormValue('cmi.core.student_name', name);
    commitScormData();
    
    // Only send to backend API if different and not debounced
    if (shouldMakeApiCall('cmi.core.student_name', name)) {
      sendScormData('cmi.core.student_name', name);
    }
  };

  const trackInteraction = (id: string, type: string, response: string, result: 'correct' | 'incorrect' | 'neutral' = 'neutral') => {
    const interactionData = {
      id,
      type,
      response,
      result,
      timestamp: new Date().toISOString()
    };
    
    setScormValue('cmi.interactions._count', (parseInt(getScormValue('cmi.interactions._count') || '0') + 1).toString());
    setScormValue(`cmi.interactions.${interactionData.id}.id`, id);
    setScormValue(`cmi.interactions.${interactionData.id}.type`, type);
    setScormValue(`cmi.interactions.${interactionData.id}.student_response`, response);
    setScormValue(`cmi.interactions.${interactionData.id}.result`, result);
    commitScormData();
    
    // Only send to backend API if not debounced
    if (shouldMakeApiCall('cmi.interactions', JSON.stringify(interactionData))) {
      sendScormData('cmi.interactions', JSON.stringify(interactionData));
    }
  };

  // Enhanced comment tracking with filtering
  const trackComment = (commentData: any) => {
    console.log('[SCORM] trackComment called with:', commentData);
    
    // Apply filtering to prevent meaningless tracking
    if (!shouldTrackStyleChange(commentData)) {
      console.log('[SCORM] Skipping meaningless style change:', commentData.text?.substring(0, 50));
      return;
    }
    
    console.log('[SCORM] Proceeding with trackComment for:', commentData.text?.substring(0, 50));
    
    const jsonData = JSON.stringify(commentData);
    
    // Only send if not debounced and meaningful
    if (shouldMakeApiCall('cmi.comments', jsonData)) {
      console.log('[SCORM] Sending API call for comment');
      setScormValue('cmi.comments', jsonData);
      commitScormData();
      sendScormData('cmi.comments', jsonData);
    } else {
      console.log('[SCORM] API call blocked by debouncing/rate limiting');
    }
  };

  return {
    setScore,
    setStatus,
    getSuspendData,
    setSuspendData,
    getProgress,
    setProgress,
    setBookmark,
    setStudentName,
    trackInteraction,
    trackComment, // Add the new filtered comment tracking
    // Direct access to SCORM functions
    setScormValue,
    getScormValue,
    commitScormData
  };
};

export const sendScormData = async (
  element: string,
  value: string
) => {
  try {
    const userId = sessionStorage.getItem('userID');
    const courseAssetId = sessionStorage.getItem('courseAssetId');
    
    if (!courseAssetId) {
      console.warn('courseAssetId not found in session storage');
      return;
    }

    const payload: ScormProgressData = {
      UserID: parseInt(userId, 10),
      CourseAssetID: parseInt(courseAssetId, 10),
      CSAssetID: 0,
      IsInsert: false,
      ElementName: element,
      ElementValue: value,
      CourseId: 0,
      ScheduleUserDetailID: 0
    };

    const apiBaseUrl = await getApiBaseUrl();
    
    const response = await fetch(`${apiBaseUrl}/api/UserProgress/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error('Failed to send SCORM data');
    }

    console.log('[SCORM API] Data sent successfully:', { element, value });
  } catch (error) {
    console.error('[SCORM API] Error sending data:', error);
  }
};

export const fetchScormData = async (element?: string) => {
  try {
    const userId = sessionStorage.getItem('userID');
    const courseAssetId = sessionStorage.getItem('courseAssetId');
    
    if (!courseAssetId) {
      console.warn('courseAssetId not found in session storage');
      return null;
    }

    const apiBaseUrl = await getApiBaseUrl();
    const url = element 
      ? `${apiBaseUrl}/api/UserProgress/search?userId=${encodeURIComponent(userId)}&courseAssetId=${encodeURIComponent(courseAssetId)}&elementName=${encodeURIComponent(element)}&csAssetId=0&isRecentBrowse=false&courseId=0`
      : `${apiBaseUrl}/api/UserProgress/search?userId=${encodeURIComponent(userId)}&courseAssetId=${encodeURIComponent(courseAssetId)}&csAssetId=0&isRecentBrowse=false&courseId=0`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch SCORM data');
    }

    const data = await response.json();
    console.log('[SCORM API] Data fetched successfully:', data);
    return data;
  } catch (error) {
    console.error('[SCORM API] Error fetching data:', error);
    return null;
  }
};

// Utility functions for SCORM data management
export const saveScormProgress = async (progressData: {
  lessonStatus?: string;
  score?: number;
  suspendData?: any;
  lessonLocation?: string;
  progressMeasure?: number;
}) => {
  try {
    const userId = sessionStorage.getItem('userID');
    const courseAssetId = sessionStorage.getItem('courseAssetId');
    
    if (!courseAssetId) {
      console.warn('courseAssetId not found in session storage');
      return;
    }

    const apiBaseUrl = await getApiBaseUrl();
    
    // Save each progress element
    const promises = [];
    
    if (progressData.lessonStatus) {
      promises.push(sendScormData('cmi.core.lesson_status', progressData.lessonStatus));
    }
    
    if (progressData.score !== undefined) {
      promises.push(sendScormData('cmi.core.score.raw', progressData.score.toString()));
    }
    
    if (progressData.suspendData) {
      promises.push(sendScormData('cmi.suspend_data', JSON.stringify(progressData.suspendData)));
    }
    
    if (progressData.lessonLocation) {
      promises.push(sendScormData('cmi.core.lesson_location', progressData.lessonLocation));
    }
    
    if (progressData.progressMeasure !== undefined) {
      promises.push(sendScormData('cmi.core.progress_measure', progressData.progressMeasure.toString()));
    }

    await Promise.all(promises);
    console.log('[SCORM] Progress saved successfully:', progressData);
  } catch (error) {
    console.error('[SCORM] Error saving progress:', error);
  }
};

// Bookmark functionality
export const createBookmark = async (pageData: {
  page: string;
  scrollPosition?: number;
  timestamp?: string;
}) => {
  const bookmarkData = {
    ...pageData,
    timestamp: pageData.timestamp || new Date().toISOString()
  };
  
  return saveScormProgress({
    suspendData: { bookmark: bookmarkData }
  });
};

// Completion tracking
export const markCompletion = async (score?: number, status: 'completed' | 'passed' | 'failed' = 'completed') => {
  return saveScormProgress({
    lessonStatus: status,
    score,
    progressMeasure: 100
  });
};
