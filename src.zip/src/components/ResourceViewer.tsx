import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect } from "react";
import { lockBodyScroll, unlockBodyScroll } from '@/utils/scrollLock';
import PDFViewer from "@/components/PDFViewer";

interface ResourceViewerProps {
  resource: {
    type: string;
    title: string;
    url: string;
  };
  onClose: () => void;
}

const ResourceViewer = ({ resource, onClose }: ResourceViewerProps) => {
  // Lock body scroll when modal is open
  useEffect(() => {
    lockBodyScroll();

    // Cleanup on unmount
    return () => {
      unlockBodyScroll();
    };
  }, []);

  const isPdf = (() => {
    const url = (resource.url || "").toLowerCase();
    const type = (resource.type || "").toString().toLowerCase();
    return (
      url.includes('.pdf') ||
      type === 'pdf' ||
      type === '2' ||
      type === 'worksheet' ||
      type === 'lessonplan'
    );
  })();

  return (
    <Card className="fixed inset-0 sm:inset-2 md:top-20 md:bottom-5 md:left-4 md:right-4 lg:left-0 lg:right-0 z-50 mx-auto w-full max-w-5xl shadow-lg flex flex-col overflow-hidden h-screen sm:h-[calc(100vh-16px)] md:h-[calc(100vh-100px)] rounded-none sm:rounded-lg">  
      <CardHeader className="flex flex-row items-center justify-between pb-4 flex-shrink-0 px-3 sm:px-4 md:px-6 py-3 sm:py-4 border-b">
        <CardTitle className="text-sm sm:text-base md:text-lg truncate flex-1 mr-2">{resource.title}</CardTitle>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="hover:bg-blue-500 flex-shrink-0 h-8 w-8 sm:h-10 sm:w-10"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5" />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 p-2 sm:p-3 md:p-4 lg:p-6 overflow-y-auto overflow-x-hidden overscroll-contain touch-pan-y [-webkit-overflow-scrolling:touch] [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar]:h-2 relative">
        {resource.type === "video" ? (
          <div className="aspect-video w-full h-full max-h-[60vh] sm:max-h-[70vh] md:max-h-[80vh]">
            <iframe
              src={resource.url}
              className="w-full h-full rounded-lg"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        ) : isPdf ? (
          <div className="w-full h-full">
            <PDFViewer pdfPath={resource.url} className="h-full min-h-[50vh]" />
          </div>
        ) : (
          <div className="w-full h-full">
            <iframe
              src={resource.url}
              className="w-full h-full rounded-lg border border-border"
              title={resource.title}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ResourceViewer;
