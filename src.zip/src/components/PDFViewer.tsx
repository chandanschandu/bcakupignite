import { getApiBaseUrl } from '@/utils/config';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, ChevronRight, Download, ZoomIn, ZoomOut, Maximize2, Minimize2 } from 'lucide-react';
import { attachHtmlTracking, trackPageView, trackCompletion } from '../scorm/ScormEventBridge';
import { clearScormCache, hydrateCachedValue, trackScormElement } from '../scorm/ScormTracker';

interface PDFViewerProps {
  pdfPath?: string;
  className?: string;
  style?: React.CSSProperties;
  isFullscreen?: boolean;
  isHeaderVisible?: boolean;
  onFullscreenToggle?: () => void;
  initialPage?: number;
  onPageChange?: (page: number) => void;
}

// Helper function to check if content is HTML
const isHtmlContent = (path: string): boolean => {
  if (!path) return false;
  const lowerPath = path.toLowerCase();
  return (
    lowerPath.endsWith('.html') || 
    lowerPath.endsWith('.htm') || 
    lowerPath.includes('index.html') ||
    (path.startsWith('http') && !lowerPath.endsWith('.pdf')) ||
    path.startsWith('<') ||
    path.startsWith('<!DOCTYPE') ||
    path.includes('<html') ||
    path.includes('<body')
  );
};

declare global {
  interface Window {
    pdfjsLib: any;
    saveNoteContent?: (event: any, pageIndex: number) => void;
    openSavedNoteConent?: (pageIndex: number) => void;
    closeID?: (event: any, pageIndex: number) => void;
    createNote?: (event: any, isBlockNote?: boolean) => void;
  }
}

const PDFViewer: React.FC<PDFViewerProps> = ({ 
  pdfPath = '/oxfordignite/Maths_Grade4_Ch04.pdf', 
  className = '',
  style = {},
  isFullscreen = false,
  isHeaderVisible = true,
  onFullscreenToggle,
  initialPage = 1,
  onPageChange
}) => {
  // Clean HTML content to ensure it's properly formatted without duplication
  const cleanHtmlContent = (html: string): string => {
    if (!html) return '';
    
    // If it's a complete HTML document, extract just the body content
    let bodyContent = html;
    
    // Remove any existing HTML/HEAD/BODY tags if present
    bodyContent = bodyContent.replace(/<\/? (html|head|body)[^>]*>/gi, '');
    
    // Remove any doctype declarations
    bodyContent = bodyContent.replace(/<!DOCTYPE[^>]*>/i, '');
    
    // Remove any script tags for security
    bodyContent = bodyContent.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
    
    // Clean up any extra whitespace
    bodyContent = bodyContent.trim();
    
    // Get the fullscreen-specific styles
    const fullscreenStyles = isFullscreen ? 'max-height: calc(100vh - 120px) !important;' : '';
    
    // Create a clean, minimal HTML document with horizontal scrolling support
    return `<!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            height: 100% !important;
            overflow: auto !important;
            ${fullscreenStyles}
          }
          
          /* Horizontal scrolling for screens less than 900px */
          @media (max-width: 900px) {
            html, body {
              overflow-x: auto !important;
              overflow-y: auto !important;
              width: 100% !important;
              min-width: 900px !important;
              /* Hide scrollbar but keep functionality */
              scrollbar-width: none !important; /* Firefox */
              -ms-overflow-style: none !important; /* IE and Edge */
            }
            
            /* Hide scrollbar for Chrome, Safari, Opera */
            html::-webkit-scrollbar,
            body::-webkit-scrollbar {
              display: none !important;
            }
            
            body {
              margin: 0 !important;
              padding: 0 !important;
            }
            
            /* Ensure tables don't break layout */
            table {
              table-layout: fixed !important;
              min-width: 100% !important;
            }
            
            /* Handle full screen mode */
            :fullscreen {
              overflow-x: auto !important;
              scrollbar-width: none !important;
              -ms-overflow-style: none !important;
            }
            
            :fullscreen::-webkit-scrollbar {
              display: none !important;
            }
            
            :-webkit-full-screen {
              overflow-x: auto !important;
            }
            
            :-webkit-full-screen::-webkit-scrollbar {
              display: none !important;
            }
            
            :-moz-full-screen {
              overflow-x: auto !important;
              scrollbar-width: none !important;
            }
            
            :-ms-fullscreen {
              overflow-x: auto !important;
              -ms-overflow-style: none !important;
            }
          }
          
          body {
            font-family: Arial, sans-serif;
            line-height: 1.5;
            background: white !important;
            padding: 5px !important;
            max-width: none !important;
            width: 100% !important;
            box-sizing: border-box !important;
            margin: 0 !important;
            min-height: 100vh !important;
            overflow-x: hidden !important;
          }
          * {
            margin: 0 !important;
            padding: 0 !important;
          }
          p, div, span, h1, h2, h3, h4, h5, h6 {
            margin-bottom: 8px !important;
          }
          img, video, iframe, table {
            max-width: 100% !important;
            height: auto !important;
            display: block !important;
            margin-bottom: 10px !important;
          }
          * {
            box-sizing: border-box !important;
          }
          
          /* Hide scrollbar class for webkit browsers */
          .hide-scrollbar::-webkit-scrollbar {
            display: none !important;
          }
          
          .hide-scrollbar {
            -ms-overflow-style: none !important; /* IE and Edge */
            scrollbar-width: none !important; /* Firefox */
          }
        </style>
      </head>
      <body>${bodyContent}</body>
      </html>`;
  };

  // Check if the content is HTML or a URL at the top level
  const isHtml = isHtmlContent(pdfPath || '');
  const isUrl = (pdfPath?.startsWith('http') || pdfPath?.startsWith('/')) && !pdfPath?.toLowerCase().endsWith('.pdf');
  
  // Clean the HTML content if needed
  const processedHtml = useMemo(() => {
    return isHtml && pdfPath ? cleanHtmlContent(pdfPath) : '';
  }, [isHtml, pdfPath]);
  
  // Generate iframe source
  const iframeSrc = useMemo(() => {
    if (!pdfPath) return '';
    
    if (isHtml) {
      return `data:text/html;charset=utf-8,${encodeURIComponent(processedHtml)}`;
    } else if (isUrl) {
      if (pdfPath.startsWith('http')) return pdfPath;

      const envBase = import.meta.env.BASE_URL || '/';
      const derivedBase = window.location.pathname.startsWith('/oxfordignite/') ? '/oxfordignite/' : '/';
      const baseUrl = envBase !== '/' ? envBase : derivedBase;
      if (pdfPath.startsWith('/src/')) {
        return `${baseUrl}${pdfPath.slice(1)}`;
      }

      return pdfPath;
    }
    return '';
  }, [pdfPath, isHtml, isUrl, processedHtml]);
  
  // All hooks must be called unconditionally at the top level
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [pdfDocument, setPdfDocument] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [totalPages, setTotalPages] = useState(0);
  const [scale, setScale] = useState(1.0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [isRendering, setIsRendering] = useState(false);
  const [currentPdfPath, setCurrentPdfPath] = useState<string>('');
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);

  // Update screen width on resize
  useEffect(() => {
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Add CSS for hiding scrollbars
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .hide-scrollbar::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      .hide-scrollbar {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
    `;
    document.head.appendChild(style);
    
    return () => {
      document.head.removeChild(style);
    };
  }, []);
  const [elementValues, setElementValues] = useState<{[key: string]: string}>({});
  const [pdfRenderMode, setPdfRenderMode] = useState<'pdfjs' | 'iframe'>('pdfjs');
  const observerRef = useRef<MutationObserver | null>(null);
  const ebookIframeRef = useRef<HTMLIFrameElement>(null);

  const [isPrefetched, setIsPrefetched] = useState(false);
  const prefetchedProgressRef = useRef<any[] | null>(null);

  const upsertSuspendDataJson = (updater: (prev: any) => any) => {
    const prevRaw = elementValues['cmi.suspend_data'];
    let prevObj: any = {};
    if (typeof prevRaw === 'string' && prevRaw.trim().length > 0) {
      try {
        prevObj = JSON.parse(prevRaw);
      } catch {
        prevObj = {};
      }
    }

    const nextObj = updater(prevObj);
    const nextRaw = JSON.stringify(nextObj ?? {});

    setElementValues(prev => ({
      ...prev,
      ['cmi.suspend_data']: nextRaw
    }));

    updateUserProgress('cmi.suspend_data', nextRaw);
    trackScormElement('cmi.suspend_data', nextRaw);
  };

  useEffect(() => {
    const w = window as any;

    const ensureNoteRoot = (innerDoc: Document, pageIndex: number) => {
      const rootId = 'NoteBookmark' + pageIndex;
      let root = innerDoc.getElementById(rootId) as HTMLDivElement | null;
      if (root) return root;

      // Try finding the page container by ID (p1, p2, etc.) or by class/attribute
      let host = innerDoc.getElementById('p' + pageIndex) as HTMLDivElement | null;
      
      if (!host) {
        // Fallback for single page or different naming
        host = innerDoc.querySelector('.page-container') as HTMLDivElement | null ||
               innerDoc.querySelector('.magazine-page') as HTMLDivElement | null ||
               innerDoc.body as unknown as HTMLDivElement;
      }

      if (!host) return null;

      // Inject CSS to ensure host can show children
      if (host.style.position !== 'absolute' && host.style.position !== 'relative') {
        host.style.position = 'relative';
      }

      root = innerDoc.createElement('div');
      root.id = rootId;
      root.className = 'NoteClsBookmark';
      root.setAttribute(
        'style',
        'z-index:999999 !important; position:absolute; width:100%; height:100%; background:transparent; top:0px; left:0px; pointer-events:none; display:block !important; visibility:visible !important;'
      );
      host.appendChild(root);
      return root;
    };

    const renderSavedNote = (pageIndex: number, note: any) => {
      try {
        const outerDoc = ebookIframeRef.current?.contentDocument;
        if (!outerDoc) return;

        const retryKey = String(pageIndex ?? '');
        if (!(w as any).__igniteNoteRenderRetries) (w as any).__igniteNoteRenderRetries = {};
        const retriesMap = (w as any).__igniteNoteRenderRetries as Record<string, number>;
        const currentAttempt = typeof retriesMap[retryKey] === 'number' ? retriesMap[retryKey] : 0;

        // Try multiple selectors for the page iframe
        console.log('[IGNITE DEBUG] renderSavedNote for page:', pageIndex);
        
        // Find ALL iframes and check their content
        const allIframes = Array.from(outerDoc.querySelectorAll('iframe'));
        let targetIframe: HTMLIFrameElement | null = null;
        
        for (const ifr of allIframes) {
          try {
            const ifrDoc = ifr.contentDocument;
            if (ifrDoc && (ifrDoc.getElementById('p' + pageIndex) || ifr.src.includes('page' + pageIndex))) {
              targetIframe = ifr;
              break;
            }
          } catch (e) { /* cross-origin */ }
        }

        let innerDoc = targetIframe?.contentDocument;
        
        if (!innerDoc) {
          const container = 
            outerDoc.querySelector(`#page${pageIndex} > iframe`) as HTMLIFrameElement | null ||
            outerDoc.querySelector(`iframe[src*="page${pageIndex}.html"]`) as HTMLIFrameElement | null ||
            outerDoc.querySelector(`iframe#page${pageIndex}`) as HTMLIFrameElement | null ||
            outerDoc.querySelector(`.page-container[data-page="${pageIndex}"] iframe`) as HTMLIFrameElement | null;
          innerDoc = container?.contentDocument;
        }
          
        if (!innerDoc) {
          const hostInOuter = outerDoc.getElementById('p' + pageIndex);
          if (hostInOuter) innerDoc = outerDoc as Document;
        }

        if (!innerDoc) {
          if (currentAttempt < 15) {
            retriesMap[retryKey] = currentAttempt + 1;
            const delay = Math.min(3000, 200 + currentAttempt * 200);
            console.warn(
              '[IGNITE DEBUG] Could not find document context for page:',
              pageIndex,
              '- retrying in',
              delay,
              'ms (attempt',
              currentAttempt + 1,
              ')'
            );
            setTimeout(() => {
              try {
                renderSavedNote(pageIndex, note);
              } catch {
                // ignore
              }
            }, delay);
          } else {
            console.warn('[IGNITE DEBUG] Gave up rendering note for page (no document):', pageIndex);
          }
          return;
        }

        const root = ensureNoteRoot(innerDoc, pageIndex);
        if (!root) {
          if (currentAttempt < 15) {
            retriesMap[retryKey] = currentAttempt + 1;
            const delay = Math.min(3000, 200 + currentAttempt * 200);
            console.warn(
              '[IGNITE DEBUG] Could not create note root for page:',
              pageIndex,
              '- retrying in',
              delay,
              'ms (attempt',
              currentAttempt + 1,
              ')'
            );
            setTimeout(() => {
              try {
                renderSavedNote(pageIndex, note);
              } catch {
                // ignore
              }
            }, delay);
          } else {
            console.warn('[IGNITE DEBUG] Gave up rendering note for page (no root):', pageIndex);
          }
          return;
        }

        // success: reset retry counter for this page
        retriesMap[retryKey] = 0;

        const iconId = 'noteSavedInfoID' + pageIndex;
        let icon = innerDoc.getElementById(iconId) as HTMLImageElement | null;

        if (!icon) {
          icon = innerDoc.createElement('img');
          icon.id = iconId;
          icon.setAttribute('draggable', 'false');
          icon.className = 'noteSavedInfo' + pageIndex;
          
          // Use a default data URI for the icon to guarantee visibility regardless of network/403
          const yellowNoteIcon = `data:image/svg+xml;base64,${btoa(`
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="#FFD700" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M15.5 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3z"></path>
              <polyline points="15 3 15 9 21 9"></polyline>
              <line x1="9" y1="13" x2="15" y2="13"></line>
              <line x1="9" y1="17" x2="15" y2="17"></line>
            </svg>
          `)}`;
          
          icon.src = yellowNoteIcon;
        icon.style.position = 'absolute';
        icon.style.zIndex = '999999';
        icon.style.width = '28px';
        icon.style.height = '28px';
        icon.style.display = 'block';
        icon.style.visibility = 'visible';
        icon.style.pointerEvents = 'auto';
        icon.style.cursor = 'pointer';
        root.appendChild(icon);
        }

        let x0 = typeof note?.x === 'number' ? note.x : 20;
        let y0 = typeof note?.y === 'number' ? note.y : 20;

        // If we still have default coords, anchor icon to the visible note panel (when present)
        try {
          if (x0 === 20 && y0 === 20) {
            const panel = innerDoc.querySelector(`#NoteBookmark${pageIndex} .notePanel`) as HTMLElement | null;
            const host = innerDoc.getElementById('p' + pageIndex) as HTMLElement | null;
            if (panel && host) {
              const hostRect = host.getBoundingClientRect();
              const panelRect = panel.getBoundingClientRect();
              x0 = Math.max(0, Math.round(panelRect.left - hostRect.left));
              y0 = Math.max(0, Math.round(panelRect.top - hostRect.top));
            }
          }
        } catch {
          // ignore
        }

        const x = Math.max(0, Math.min(2000, x0));
        const y = Math.max(0, Math.min(2000, y0));
        icon.style.left = `${x}px`;
        icon.style.top = `${y}px`;

        const panelId = 'notePanelID' + pageIndex;
        const closePanel = () => {
          const existing = innerDoc.getElementById(panelId);
          if (existing) existing.remove();
        };

        const openPanel = () => {
          closePanel();
          const panel = innerDoc.createElement('div');
          panel.id = panelId;
          panel.className = 'notePanel';
          panel.style.position = 'absolute';
          panel.style.left = `${Math.max(0, x - 10)}px`;
          panel.style.top = `${Math.max(0, y - 10)}px`;
          panel.style.width = '280px';
          panel.style.height = '250px';
          panel.style.padding = '10px';
          panel.style.background = '#ff7eb9';
          panel.style.zIndex = '11';
          panel.style.pointerEvents = 'auto';
          panel.style.fontFamily = 'inherit';

          const closeBtn = innerDoc.createElement('button');
          closeBtn.textContent = '×';
          closeBtn.style.cssText =
            'float:right; font-size:32px; cursor:pointer; background:#E01C12; width:40px; border-radius:40px; height:40px; line-height:30px; color:#fff; margin-bottom:5px; border:none;';
          closeBtn.onclick = (ev) => {
            try { (ev as any)?.stopPropagation?.(); } catch {}
            closePanel();
          };

          const title = innerDoc.createElement('span');
          title.textContent = 'Note';
          title.style.cssText = 'float:left; font-size:26px; font-weight:bold;';

          const textarea = innerDoc.createElement('textarea');
          textarea.className = 'noteInput';
          textarea.maxLength = 50;
          textarea.placeholder = 'Enter note description here (max 50 chrs)';
          textarea.value = typeof note?.text === 'string' ? note.text : '';
          textarea.style.cssText =
            'width:260px; height:150px; background:transparent; border:0.05em dashed; font-weight:bold; outline:none; font-size:26px; z-index:3; resize:none; padding:5px; margin-top:10px;';
          textarea.onclick = (ev) => {
            try { (ev as any)?.stopPropagation?.(); } catch {}
          };

          const saveBtn = innerDoc.createElement('button');
          saveBtn.textContent = 'SAVE';
          saveBtn.style.cssText =
            "border:none; float:right; margin-top:8px; padding-top:6px; background:#0CC; width:65px; height:32px; font-weight:bold; font-size:19px; cursor:pointer; font-family:inherit;";
          saveBtn.onclick = (ev) => {
            w.saveNoteContent(ev, pageIndex);
          };

          panel.appendChild(closeBtn);
          panel.appendChild(title);
          panel.appendChild(textarea);
          panel.appendChild(saveBtn);
          root.appendChild(panel);
        };

        icon.onclick = (ev) => {
          try { (ev as any)?.stopPropagation?.(); } catch {}
          const existing = innerDoc.getElementById(panelId);
          if (existing) {
            existing.remove();
          } else {
            openPanel();
          }
        };
      } catch {
        // ignore
      }
    };

    w.__igniteRenderSavedNote = renderSavedNote;

    const getNoteTextFromDom = (pageIndex?: number) => {
      try {
        const doc = ebookIframeRef.current?.contentDocument;
        if (!doc) return '';

        if (typeof pageIndex === 'number' && pageIndex >= 0) {
          const container = doc.querySelector(`#page${pageIndex} > iframe`) as HTMLIFrameElement | null;
          const innerDoc = container?.contentDocument;
          const val = innerDoc
            ?.querySelector('#NoteBookmark' + pageIndex + ' .notePanel .noteInput') as HTMLTextAreaElement | null;
          if (val && typeof val.value === 'string') return val.value;
        }

        const anyTextarea = doc.querySelector('textarea.noteInput') as HTMLTextAreaElement | null;
        if (anyTextarea && typeof anyTextarea.value === 'string') return anyTextarea.value;

        return '';
      } catch {
        return '';
      }
    };

    w.saveNoteContent = (event: any, pageIndex: number) => {
      try {
        event?.stopPropagation?.();
      } catch {
        // ignore
      }

      const noteText = getNoteTextFromDom(pageIndex);
      const lastPos = (w.__igniteLastNotePos && w.__igniteLastNotePos[String(pageIndex)]) || {};
      let x = typeof lastPos.x === 'number' ? lastPos.x : 20;
      let y = typeof lastPos.y === 'number' ? lastPos.y : 20;
      const ts = new Date().toISOString();

      try {
        if (x === 20 && y === 20) {
          const outerDoc = ebookIframeRef.current?.contentDocument;
          const container = 
            outerDoc?.querySelector(`#page${pageIndex} > iframe`) as HTMLIFrameElement | null ||
            outerDoc?.querySelector(`iframe[src*="page${pageIndex}.html"]`) as HTMLIFrameElement | null ||
            outerDoc?.querySelector(`.page-container[data-page="${pageIndex}"] iframe`) as HTMLIFrameElement | null;
          
          let innerDoc = container?.contentDocument;
          if (!innerDoc && outerDoc?.getElementById('p' + pageIndex)) {
            innerDoc = outerDoc as Document;
          }
          
          const host = innerDoc?.getElementById('p' + pageIndex);
          console.log('[IGNITE DEBUG] saveNoteContent - host found:', !!host);
          const panel = innerDoc?.querySelector(`#NoteBookmark${pageIndex} .notePanel`) as HTMLElement | null;
          console.log('[IGNITE DEBUG] saveNoteContent - panel found:', !!panel);
          if (host && panel) {
            const hostRect = host.getBoundingClientRect();
            const panelRect = panel.getBoundingClientRect();
            x = Math.max(0, Math.round(panelRect.left - hostRect.left));
            y = Math.max(0, Math.round(panelRect.top - hostRect.top));
          }
        }
      } catch {
        // ignore
      }

      upsertSuspendDataJson((prev) => {
        const next = { ...(prev ?? {}) };
        const notes = { ...(next.notes ?? {}) };
        notes[String(pageIndex ?? '')] = {
          text: noteText,
          timestamp: ts,
          x,
          y
        };
        next.notes = notes;
        return next;
      });

      renderSavedNote(pageIndex, { text: noteText, timestamp: ts, x, y });
    };

    w.openSavedNoteConent = (pageIndex: number) => {
      trackScormElement(
        'cmi.suspend_data',
        JSON.stringify({
          type: 'note_open',
          page: String(pageIndex ?? ''),
          timestamp: new Date().toISOString()
        })
      );
    };

    w.closeID = (event: any, pageIndex: number) => {
      try {
        event?.stopPropagation?.();
      } catch {
        // ignore
      }
      trackScormElement(
        'cmi.suspend_data',
        JSON.stringify({
          type: 'note_delete',
          page: String(pageIndex ?? ''),
          timestamp: new Date().toISOString()
        })
      );
    };

    w.createNote = (event: any, isBlockNote?: boolean) => {
      try {
        event?.stopPropagation?.();
      } catch {
        // ignore
      }

      try {
        if (!w.__igniteLastNotePos) w.__igniteLastNotePos = {};
        const offsetX = typeof event?.offsetX === 'number' ? event.offsetX : undefined;
        const offsetY = typeof event?.offsetY === 'number' ? event.offsetY : undefined;

        const clientX =
          typeof event?.clientX === 'number'
            ? event.clientX
            : (typeof event?.pageX === 'number' ? event.pageX : undefined);
        const clientY =
          typeof event?.clientY === 'number'
            ? event.clientY
            : (typeof event?.pageY === 'number' ? event.pageY : undefined);

        let pageIndex: string | undefined;
        const parentId = event?.target?.parentNode?.id;
        if (typeof parentId === 'string' && parentId.startsWith('p')) {
          const idx = parentId.slice(1);
          if (idx.length > 0) pageIndex = idx;
        }

        if (!pageIndex) {
          const selfId = event?.target?.id;
          if (typeof selfId === 'string' && selfId.startsWith('NoteBookmark')) {
            const idx = selfId.replace('NoteBookmark', '');
            if (idx.length > 0) pageIndex = idx;
          }
        }

        if (pageIndex) {
          if (typeof offsetX === 'number' && typeof offsetY === 'number') {
            w.__igniteLastNotePos[String(pageIndex)] = { x: offsetX, y: offsetY };
            return;
          }

          if (typeof clientX === 'number' && typeof clientY === 'number') {
            const target = event?.target as HTMLElement | undefined;
            if (target && typeof target.getBoundingClientRect === 'function') {
              const rect = target.getBoundingClientRect();
              const x = Math.max(0, Math.round(clientX - rect.left));
              const y = Math.max(0, Math.round(clientY - rect.top));
              w.__igniteLastNotePos[String(pageIndex)] = { x, y };
              return;
            }
          }
        }
      } catch {
        // ignore
      }
    };

    return () => {
      if (w.saveNoteContent) delete w.saveNoteContent;
      if (w.openSavedNoteConent) delete w.openSavedNoteConent;
      if (w.closeID) delete w.closeID;
      if (w.createNote) delete w.createNote;
      if (w.__igniteRenderSavedNote) delete w.__igniteRenderSavedNote;
    };
  }, []);

  useEffect(() => {
    if (!iframeLoaded) return;
    const w = window as any;
    const renderFn = w.__igniteRenderSavedNote as undefined | ((pageIndex: number, note: any) => void);
    if (typeof renderFn !== 'function') return;

    const raw = elementValues['cmi.suspend_data'];
    if (!raw || typeof raw !== 'string') return;

    let obj: any = {};
    try {
      obj = JSON.parse(raw);
    } catch {
      return;
    }

    const notes = obj?.notes;
    if (!notes || typeof notes !== 'object') return;

    Object.keys(notes).forEach((k) => {
      const idx = Number(k);
      if (!Number.isFinite(idx)) return;
      renderFn(idx, notes[k]);
    });
  }, [iframeLoaded, elementValues]);
  
  const fetchUserProgress = async () => {
    try {
      const userId = sessionStorage.getItem('userID');
      const courseAssetId = sessionStorage.getItem('courseAssetId');
      
      if (!courseAssetId) {
        console.warn('courseAssetId not found in session storage');
        setIsPrefetched(true);
        return;
      }
      
      const apiBaseUrl = await getApiBaseUrl();
      const progressUrl = `${apiBaseUrl}/api/UserProgress/search?userId=${encodeURIComponent(userId)}&courseAssetId=${encodeURIComponent(courseAssetId)}&csAssetId=0&isRecentBrowse=false&courseId=0`;
      
      const response = await fetch(progressUrl, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) throw new Error('Failed to fetch user progress');
      
      const progressData = await response.json();
      console.log('Fetched user progress:', progressData);
      prefetchedProgressRef.current = Array.isArray(progressData) ? progressData : null;
      
      // Store the fetched values (latest per elementName)
      if (Array.isArray(progressData) && progressData.length > 0) {
        type ProgressRow = {
          elementName?: string;
          elementValue?: string;
          ElementName?: string;
          ElementValue?: string;
          modifiedDate?: string;
          ModifiedDate?: string;
          updatedDate?: string;
          UpdatedDate?: string;
          createdDate?: string;
          CreatedDate?: string;
          timestamp?: string;
          Timestamp?: string;
          id?: number;
          Id?: number;
        };

        const pickName = (row: ProgressRow) => (row.elementName ?? row.ElementName ?? '') as string;
        const pickValue = (row: ProgressRow) => (row.elementValue ?? row.ElementValue ?? '') as string;

        const pickTime = (row: ProgressRow): number => {
          const t =
            row.modifiedDate ??
            row.ModifiedDate ??
            row.updatedDate ??
            row.UpdatedDate ??
            row.createdDate ??
            row.CreatedDate ??
            row.timestamp ??
            row.Timestamp;
          const ms = t ? Date.parse(t) : NaN;
          if (!Number.isNaN(ms)) return ms;

          const id = row.id ?? row.Id;
          if (typeof id === 'number') return id;

          return 0;
        };

        const latest = new Map<string, { value: string; order: number; time: number }>();
        (progressData as ProgressRow[]).forEach((row, order) => {
          const name = pickName(row);
          const value = pickValue(row);
          if (!name || !value) return;

          const time = pickTime(row);
          const existing = latest.get(name);
          if (!existing) {
            latest.set(name, { value, order, time });
            return;
          }

          // Prefer newer timestamps, otherwise later in array
          if (time > existing.time || (time === existing.time && order > existing.order)) {
            latest.set(name, { value, order, time });
          }
        });

        const nextValues: Record<string, string> = {};
        latest.forEach((v, k) => {
          nextValues[k] = v.value;
        });

        if (nextValues['cmi.suspend_data']) {
          console.log('[IGNITE DEBUG] Loaded cmi.suspend_data length:', nextValues['cmi.suspend_data'].length);
        } else {
          console.warn('[IGNITE DEBUG] No cmi.suspend_data found in progress response');
        }

        setElementValues(prev => ({
          ...prev,
          ...nextValues
        }));

        // Hydrate SCORM in-memory cache so Reader's early LMSGetValue gets backend values
        Object.keys(nextValues).forEach((k) => {
          try {
            const v = nextValues[k];
            if (k === 'cmi.comments') {
              const trimmed = typeof v === 'string' ? v.trim() : '';
              if (!trimmed) return;
              if (!trimmed.startsWith('[')) return;
              try {
                const parsed = JSON.parse(trimmed);
                if (!Array.isArray(parsed)) return;
              } catch {
                return;
              }
              hydrateCachedValue(k, trimmed);
              return;
            }

            hydrateCachedValue(k, v);
          } catch {
            // ignore
          }
        });
      }

      setIsPrefetched(true);
    } catch (error) {
      console.error('Error fetching progress:', error);
      // Even on failure, allow iframe to load so app isn't stuck.
      setIsPrefetched(true);
    }
  };

  // Prefetch progress for HTML/ebook content so highlights can restore on first paint.
  useEffect(() => {
    if (!isHtml && !isUrl) return;
    // New content load: clear any in-memory SCORM cache so we only use backend values for this asset.
    try {
      clearScormCache();
    } catch {
      // ignore
    }
    prefetchedProgressRef.current = null;
    setIsPrefetched(false);
    fetchUserProgress();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHtml, isUrl, pdfPath]);

  // Function to update user progress (POST)
  const updateUserProgress = async (elementName: string, elementValue: string) => {
    try {
      // Don't update if values are empty or haven't changed
      if (!elementName || !elementValue || elementValues[elementName] === elementValue) {
        console.log('Skipping update - no change or empty values');
        return;
      }
      
      const userId = sessionStorage.getItem('userID');
      const courseAssetId = sessionStorage.getItem('courseAssetId');
      
      if (!courseAssetId) {
        console.warn('courseAssetId not found in session storage');
        return;
      }
      
      // Update local state
      setElementValues(prev => ({
        ...prev,
        [elementName]: elementValue
      }));
      
      // Prepare update payload with actual values or defaults
      const updatePayload = {
        UserID: parseInt(userId, 10),
        CourseAssetID: parseInt(courseAssetId, 10),
        CSAssetID: 0,
        IsInsert: false,
        ElementName: elementName,
        ElementValue: elementValue,
        CourseId: 0,
        ScheduleUserDetailID: 0
      };
      
      console.log('Updating progress with:', updatePayload);
      
      // Update the progress
      const updateApiBaseUrl = await getApiBaseUrl();
      const updateResponse = await fetch(`${updateApiBaseUrl}/api/UserProgress/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatePayload)
      });
      
      if (!updateResponse.ok) {
        throw new Error('Failed to update progress');
      }
      
      console.log('Progress updated successfully');
    } catch (error) {
      console.error('Error updating progress:', error);
    }
  };

  // Track if we've already processed an update in this cycle
  const updateInProgressRef = useRef(false);
  
  // Function to handle style changes
  const handleStyleChanges = (mutations: MutationRecord[]) => {
    // Prevent multiple updates in the same cycle
    if (updateInProgressRef.current) return;
    updateInProgressRef.current = true;
    
    try {
      // Process mutations
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          const target = mutation.target as HTMLElement;
          
          // Only process style/class changes
          if (mutation.attributeName === 'style' || mutation.attributeName === 'class') {
            const elementName = target.getAttribute('data-element-name');
            const elementValue = target.getAttribute('data-element-value');
            
            // Only update if we have both name and value
            if (elementName && elementValue) {
              // Use the values from the element's data attributes
              updateUserProgress(elementName, elementValue);
              return; // Exit after first valid update
            }
          }
        }
      }
    } finally {
      // Reset the flag in the next tick to allow future updates
      setTimeout(() => {
        updateInProgressRef.current = false;
      }, 0);
    }
  };
  
  // Refs for PDF rendering
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const loadedPdfPathRef = useRef<string>('');
  const currentRenderTask = useRef<any>(null);

  // For testing, use a known working PDF URL if local PDF fails
  const testPdfUrl = 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';

  // Handle browser back button
  useEffect(() => {
    const handleBackButton = (event: PopStateEvent) => {
      // Prevent default back navigation
      event.preventDefault();
      
      // Show loading state
      setLoading(true);
      
      // Force a page reload after a short delay
      const timer = setTimeout(() => {
        window.location.reload();
      }, 500);
      
      return () => clearTimeout(timer);
    };

    // Add a new entry to the history stack
    window.history.pushState(null, '', window.location.href);
    
    // Add event listener
    window.addEventListener('popstate', handleBackButton);
    
    // Clean up
    return () => {
      window.removeEventListener('popstate', handleBackButton);
    };
  }, []);

  // Update current page when initialPage prop changes (for fullscreen mode)
  useEffect(() => {
    if (pdfDocument) {
      console.log("PDFViewer: Updating page from initialPage prop:", initialPage);
      setCurrentPage(initialPage);
      renderPage(pdfDocument, initialPage, scale);
    }
  }, [initialPage, pdfDocument]);

  // Handle loading PDF or HTML content
  useEffect(() => {
    const loadPDF = async () => {
      // Skip PDF loading if the content is HTML
      if (isHtml || isUrl) {
        console.log('HTML/URL content detected, skipping PDF loading');
        setLoading(false);
        return;
      }
      
      if (pdfRenderMode === 'iframe') {
        setLoading(false);
        return;
      }
      
      // Skip if no PDF path is provided
      if (!pdfPath) {
        setLoading(false);
        return;
      }
      
      // Check if PDF path is empty or null
      if (!pdfPath || pdfPath.trim() === '') {
        console.log('No PDF path provided, showing blank page');
        setError(' ');
        setLoading(false);
        return;
      }
      
      // Ensure we're using HTTPS for PDF paths to avoid mixed content issues
      let normalizedPath = pdfPath;
      
      // If it's a relative path, prepend a slash if needed
      if (!pdfPath.startsWith('http')) {
        normalizedPath = pdfPath.startsWith('/') ? pdfPath : `/${pdfPath}`;
      } 
      // If it's HTTP, convert to HTTPS
      else if (pdfPath.startsWith('http://')) {
        normalizedPath = 'https' + pdfPath.substring(4);
      }
      
      // Check if this is the same PDF path to prevent unnecessary reload
      if (loadedPdfPathRef.current === normalizedPath && pdfDocument) {
        console.log('Same PDF path detected, skipping reload');
        return;
      }
      
      // Store the current path for download function and ref tracking
      setCurrentPdfPath(normalizedPath);
      loadedPdfPathRef.current = normalizedPath;
      
      try {
        setLoading(true);
        setError('');
        
        console.log('Attempting to load PDF from:', normalizedPath);
        
        // Load PDF.js from CDN
        if (!window.pdfjsLib) {
          console.log('Loading PDF.js from CDN...');
          const script = document.createElement('script');
          script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
          script.async = true;
          
          await new Promise((resolve, reject) => {
            script.onload = () => {
              console.log('PDF.js loaded successfully');
              resolve(undefined);
            };
            script.onerror = () => {
              console.error('Failed to load PDF.js');
              reject(new Error('Failed to load PDF.js'));
            };
            document.head.appendChild(script);
          });
        } else {
          console.log('PDF.js already loaded');
        }
        
        // Set worker source
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        console.log('Worker source set');
        
        const pdfToLoad = normalizedPath;
        const loadingTask = window.pdfjsLib.getDocument(pdfToLoad);
        
        loadingTask.onProgress = (progress: any) => {
          console.log('Loading progress:', progress.loaded, '/', progress.total);
        };
        
        const pdf = await loadingTask.promise;
        
        console.log('PDF loaded successfully, pages:', pdf.numPages);
        
        setPdfDocument(pdf);
        setTotalPages(pdf.numPages);
        setCurrentPage(initialPage);
        
      } catch (err: any) {
        console.error('Error loading PDF:', err);
        
        // Provide specific error messages
        let errorMessage = 'Failed to load PDF';
        if (err.name === 'InvalidPDFException') {
          errorMessage = 'Invalid or corrupted PDF file';
        } else if (err.name === 'MissingPDFException') {
          errorMessage = 'PDF file not found';
        } else if (err.name === 'PasswordException') {
          errorMessage = 'PDF requires password';
        } else if (err.message) {
          errorMessage = err.message;
        }
        
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    loadPDF();
  }, [pdfPath, isHtml, isUrl, pdfRenderMode]);

  useEffect(() => {
    setPdfRenderMode('pdfjs');
  }, [pdfPath]);

  // Track last rendered page and scale to prevent unnecessary re-renders
  const lastRenderRef = useRef({ page: 0, scale: 0 });

  // Re-render page when currentPage or scale changes
  useEffect(() => {
    if (!pdfDocument || isRendering || isHtml || isUrl || pdfRenderMode === 'iframe') return;
    
    // Only re-render if page or scale has actually changed
    if (lastRenderRef.current.page === currentPage && 
        lastRenderRef.current.scale === scale) {
      return;
    }

    const renderCurrentPage = async () => {
      if (!pdfDocument || isRendering) return;
      
      try {
        setIsRendering(true);
        console.log('Rendering page', currentPage, 'at scale', scale);
        await renderPage(pdfDocument, currentPage, scale);
        // Update last rendered values
        lastRenderRef.current = { page: currentPage, scale };
      } catch (error) {
        console.error('Error rendering page:', error);
      } finally {
        setIsRendering(false);
      }
    };

    renderCurrentPage();
  }, [currentPage, scale, pdfDocument, isRendering, isHtml, isUrl, pdfRenderMode]);

  // Set loading to false when component mounts for HTML content
  useEffect(() => {
    if (isHtml || isUrl) {
      setLoading(false);
    }
  }, [isHtml, isUrl]);

  const renderPage = async (pdf: any, pageNumber: number, currentScale: number) => {
    if (!canvasRef.current) {
      console.error('Canvas ref not available');
      return;
    }
    
    // Cancel any existing render operation
    if (currentRenderTask.current) {
      console.log('Cancelling previous render operation');
      currentRenderTask.current.cancel();
      currentRenderTask.current = null;
    }
    
    setIsRendering(true);
    
    try {
      console.log(`Rendering page ${pageNumber} at scale ${currentScale}`);
      const page = await pdf.getPage(pageNumber);
      console.log(`Page ${pageNumber} loaded, viewport:`, page.getViewport({ scale: currentScale }));
      
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (!context) {
        console.error('Canvas context not available');
        return;
      }

      // Clear canvas before rendering new page
      context.clearRect(0, 0, canvas.width, canvas.height);
      console.log('Canvas cleared');

      // Calculate scaled dimensions
      const viewport = page.getViewport({ scale: currentScale });
      
      // Set canvas dimensions for proper scrolling - allow content to be larger than viewport
      const containerHeight = viewport.height;
      const containerWidth = isFullscreen ? viewport.width : viewport.width;
      
      canvas.height = containerHeight;
      canvas.width = containerWidth;
      
      console.log(`Canvas size set to ${canvas.width}x${canvas.height} (container: ${containerWidth}x${containerHeight})`);

      // Render PDF page into canvas context
      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };
      
      // Store the render task so we can cancel it if needed
      currentRenderTask.current = page.render(renderContext);
      await currentRenderTask.current.promise;
      
      console.log(`Page ${pageNumber} rendered successfully`);
      
    } catch (err) {
      if (err instanceof Error && err.message.includes('cancelled')) {
        console.log('Render operation was cancelled');
        return;
      }
      console.error('Error rendering page:', err);
      setError(`Failed to render page ${pageNumber}: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsRendering(false);
      currentRenderTask.current = null;
    }
  };

  // Handle window resize in fullscreen mode
  useEffect(() => {
    const handleResize = () => {
      if (isFullscreen && canvasRef.current && pdfDocument && currentPage) {
        const containerHeight = window.innerHeight - 200;
        const containerWidth = window.innerWidth - 40;
        
        canvasRef.current.height = containerHeight;
        canvasRef.current.width = containerWidth;
        
        // Re-render current page with new dimensions
        renderPage(pdfDocument, currentPage, scale);
      }
    };

    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [isFullscreen, pdfDocument, currentPage, scale]);

  const handlePageChange = async (newPage: number) => {
    if (newPage < 1 || newPage > totalPages || !pdfDocument) return;
    
    setCurrentPage(newPage);
    
    // Call the onPageChange callback if provided
    if (onPageChange) {
      onPageChange(newPage);
    }
  };

  const handleZoom = async (newScale: number) => {
    const clampedScale = Math.max(0.5, Math.min(3.0, newScale));
    setScale(clampedScale);
  };

  const handleZoomIn = async () => {
    await handleZoom(scale + 0.25);
  };

  const handleZoomOut = async () => {
    await handleZoom(scale - 0.25);
  };

  const handleDownload = () => {
    window.open(currentPdfPath, '_blank');
  };

  const goToPreviousPage = () => {
    handlePageChange(currentPage - 1);
  };

  const goToNextPage = () => {
    handlePageChange(currentPage + 1);
  };


  if (loading) {
    return (
      <div className={`flex items-center justify-center h-full w-full ${className}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading EBook...</p>
        </div>
      </div>
    );
  }

  if (error) {
    // Show error message when content fails to load
    return (
      <div className={`border rounded-lg bg-background-white flex flex-col relative ${isFullscreen ? 'fixed inset-0 z-50 border-0 rounded-none' : 'h-full'} ${className}`}>
        <div className={`flex-1 overflow-auto p-4 ${isFullscreen ? 'p-8' : ''}`}
          style={{
            maxHeight: isFullscreen ? 'calc(100vh - 120px)' : 'none',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <div className="text-center">
            <p className="text-lg font-medium text-gray-800 mb-2">Unable to load content</p>
            <p className="text-gray-600">The requested content could not be loaded.</p>
            {error && <p className="text-sm text-red-500 mt-2">Error: {error}</p>}
            <button 
              onClick={() => window.location.reload()} 
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
        
        {/* Controls - Always Visible at Bottom */}
        <div className={`p-4 bg-background-white from-slate-50 to-slate-100 ${isFullscreen ? 'sticky bottom-0 z-10' : ''}`}>
          <div className="flex justify-center mb-2">
            <div className="border border-gray-100 rounded-lg p-3 bg-white shadow-sm max-w-2xl">
<div className="flex items-center justify-center space-x-4  ">                {/* Page Navigation */}
            <div className="flex items-center space-x-2">
              {/* Zoom Controls */}
              <div className="flex items-center space-x-1 bg-white border border-slate-200 rounded-md px-2 py-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onTouchStart={handleZoomOut}
                  onTouchEnd={(e) => { e.preventDefault(); handleZoomOut(); }}
                  onClick={handleZoomOut}
                  disabled={scale <= 0.5}
                  className="h-7 w-7 p-0 hover:bg-blue-700 hover:text-white active:bg-blue-600 touch-manipulation"
                >
                  <ZoomOut className="w-3 h-3" />
                </Button>
                
                <span className="text-sm text-slate-600 font-medium min-w-[45px] text-center select-none">
                  {Math.round(scale * 100)}%
                </span>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onTouchStart={handleZoomIn}
                  onTouchEnd={(e) => { e.preventDefault(); handleZoomIn(); }}
                  onClick={handleZoomIn}
                  disabled={scale >= 2.50}
                  className="h-7 w-7 p-0 hover:bg-blue-700 hover:text-white active:bg-blue-600 touch-manipulation"
                >
                  <ZoomIn className="w-3 h-3" />
                </Button>

              </div>
            </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Ensure we're using HTTPS for iframe sources to avoid mixed content issues


//  // Function to get the local path for Reader_Ignite_v1 content
//   const getLocalReaderPath = (path: string) => {
//     // If it's a full URL, extract the path after 'Reader_Ignite_v1/'
//     const match = path.match(/Reader_Ignite_v1[\\/](.*)/);
//     if (match) {
//       // Use the direct path from the project root
//       return `/src/Reader_Ignite_v1/${match[1].replace(/\\/g, '/')}`;
//     }
//     // If it's already a local path, ensure it uses forward slashes
//     if (path.includes('Reader_Ignite_v1')) {
//       return path.replace(/\\/g, '/');
//     }
//     // Otherwise, treat it as a relative path from Reader_Ignite_v1
//     return `/src/Reader_Ignite_v1/${path.replace(/^[\\/]/, '')}`;
//   };

//   // Function to get the base URL for the iframe
//   const getBaseUrl = (path: string) => {
//     // For development, use the absolute path to the project
//     if (import.meta.env.DEV) {
//       return 'http://localhost:8080/src/Reader_Ignite_v1';
//     }
//     // For production, use the public URL
//     return '/Reader_Ignite_v1';
//   };

//   // Render HTML content
//   if (isHtml || isUrl) {
//     let iframeSrc = '';
//     let baseUrl = getBaseUrl(pdfPath);
    
//     // Handle HTML content with Reader_Ignite_v1
//     if (isHtml) {
//       const relativePath = getLocalReaderPath(pdfPath).replace(/^.*?Reader_Ignite_v1[\\/]?/i, '');
//       iframeSrc = `${baseUrl}/${relativePath}`;
//     } else {
//       // Only use the URL as-is if it's not HTML content
//       iframeSrc = getIframeSrc(pdfPath);
//     }
  //  // Render HTML server
  const getIframeSrc = (url: string) => {
    if (url.startsWith('http://')) {
      return 'https' + url.substring(4);
    }
    return url;
  };
  // Render HTML server
  if (isHtml || isUrl) {
    const iframeSrc = getIframeSrc(pdfPath);

  //  // Render HTML local
  //  if (isHtml || isUrl) {
  //   const iframeSrc = "http://localhost/OA_Resources/OAIgnite/Class%201/English/Ebooks/Reader_Ignite_v1/";

    return (
      <div 
        className={`bg-white ${isFullscreen ? 'fixed inset-0 z-50' : 'h-full w-full'} ${className} hide-scrollbar`} 
        style={{
          ...style,
          width: '100%',
          height: '100%',
          margin: 0,
          padding: 0,
          overflow: 'auto',
          scrollbarWidth: 'none', // Hide scrollbar for Firefox
          msOverflowStyle: 'none', // Hide scrollbar for IE/Edge
          backgroundColor: 'white',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white z-10">
            <div className="flex flex-col items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
              <p className="text-gray-600">Loading content...</p>
            </div>
          </div>
        )}
       <div
          className={`w-full h-full flex-1 overflow-auto hide-scrollbar`}
          style={{
            position: 'relative',
            width: '100%',
            maxWidth: '100%',
            height: isFullscreen ? 'calc(100vh - 40px)' : '100%', // Account for any UI elements in fullscreen
            overflow: 'auto',
            scrollbarWidth: 'none', // Hide scrollbar for Firefox
            msOverflowStyle: 'none', // Hide scrollbar for IE/Edge
            marginBottom: isFullscreen ? '0' : '', // Remove margin in fullscreen
            padding: 0,
            margin: 0,
            backgroundColor: 'white',
            boxShadow: 'none',
            WebkitOverflowScrolling: 'touch',
            minHeight: isFullscreen ? 'calc(100vh - 40px)' : 'auto', // Ensure minimum height in fullscreen
            // Resolution-specific min-height for desktop screens (900px and above)
            ...(screenWidth >= 900 && {
              minHeight: screenWidth >= 1200 ? '856px' : 
                       screenWidth >= 1024 ? '756px' : 
                       '656px'
            })
          }}
        >
          <iframe 
            ref={ebookIframeRef}
            src={isPrefetched ? iframeSrc : 'about:blank'}
            className="border-0 w-full h-full hide-scrollbar"
            title="Ebook Content"
            sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-presentation"
            allowFullScreen
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0, // Add bottom positioning
              width: '100%',
              height: '100%',
              minHeight: '100%',
              maxWidth: '100%',
              border: 'none',
              backgroundColor: 'white',
              zIndex: '1',
              margin: 0,
              padding: 0,
              boxSizing: 'border-box', // Ensure proper box sizing
              // Hide all scrollbars completely while keeping scroll functionality
              scrollbarWidth: 'none', // Firefox
              msOverflowStyle: 'none', // IE and Edge
              overflow: 'auto'
            }}
            onLoad={async (e) => {
              if (!isPrefetched) {
                return;
              }
              if (!isPrefetched) {
                console.warn('[IGNITE] Iframe loaded before prefetch completed');
              }
              console.log('Iframe content loaded successfully');
              setLoading(false);
              setError('');
              setIframeLoaded(true);
              
              // Set up SCORM tracking for the iframe
              const iframeElement = e.target as HTMLIFrameElement;
              attachHtmlTracking(iframeElement);
              
              // Track initial page load
              trackPageView('page_1');
              
              // Prefetch already loaded and hydrated the SCORM cache. Only set up update + restore.
              try {
                // Function to update SCORM progress with actual element changes
                const updateScormProgress = async (elementName: string, elementValue: string) => {
                  try {
                    const userId = sessionStorage.getItem('userID');
                    const courseAssetId = sessionStorage.getItem('courseAssetId');
                    
                    if (!courseAssetId) {
                      console.warn('courseAssetId not found in session storage');
                      return;
                    }
                    
                    const apiBaseUrl = await getApiBaseUrl();
                    
                    // Prepare update payload with actual SCORM element data
                const updatePayload = {
                  UserID: parseInt(userId, 10),
                  CourseAssetID: parseInt(courseAssetId, 10),
                      CSAssetID: 0,
                      IsInsert: false,
                      ElementName: elementName,
                      ElementValue: elementValue,
                      CourseId: 0,
                      ScheduleUserDetailID: 0
                };
                
                    console.log('Updating SCORM progress with:', updatePayload);
                
                    const updateResponse = await fetch(`${apiBaseUrl}/api/UserProgress/update`, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify(updatePayload)
                });
                
                if (!updateResponse.ok) {
                  throw new Error('Failed to update progress');
                }
                
                    console.log('SCORM progress updated successfully:', { elementName, elementValue });
              } catch (error) {
                    console.error('Error updating SCORM progress:', error);
                  }
                };
                
                // Function to restore saved highlights and comments
                const restoreSavedContent = async () => {
                  try {
                    const userId = sessionStorage.getItem('userID');
                    const courseAssetId = sessionStorage.getItem('courseAssetId');
                    
                    if (!userId || !courseAssetId) {
                      console.warn('Missing user or course info for restoring content');
                      return;
                    }

                    const progressArray = Array.isArray(prefetchedProgressRef.current)
                      ? prefetchedProgressRef.current
                      : [];

                    if (progressArray.length === 0) {
                      console.warn('No backend progress data available for restoration');
                      return;
                    }
                    
                    // Two different formats are stored in cmi.comments:
                    // 1) Reader_Ignite_v1 ebook highlight payload: JSON array string starting with '['
                    // 2) Our custom tracking events: JSON object string starting with '{'
                    const savedEbookHighlightPayloads = progressArray
                      .filter(
                        (item) =>
                          item.elementName === 'cmi.comments' &&
                          typeof item.elementValue === 'string' &&
                          item.elementValue.trim().startsWith('[')
                      )
                      .map((item) => ({
                        raw: (item.elementValue as string).trim(),
                        time: (() => {
                          const t = (item.modifiedDate ?? item.ModifiedDate ?? item.updatedDate ?? item.UpdatedDate ?? item.createdDate ?? item.CreatedDate ?? item.timestamp ?? item.Timestamp) as
                            | string
                            | undefined;
                          const ms = t ? Date.parse(t) : NaN;
                          if (!Number.isNaN(ms)) return ms;
                          const id = (item.id ?? item.Id) as number | undefined;
                          return typeof id === 'number' ? id : 0;
                        })()
                      }));

                    const savedCustomEvents = progressArray.filter(
                      (item) =>
                        item.elementName === 'cmi.comments' &&
                        typeof item.elementValue === 'string' &&
                        item.elementValue.trim().startsWith('{')
                    );

                    if (savedEbookHighlightPayloads.length > 0 || savedCustomEvents.length > 0) {
                      console.log(
                        `Found ${savedCustomEvents.length} saved highlights/comments to restore and ${savedEbookHighlightPayloads.length} ebook highlight payload(s)`
                      );

                      const normalizeEbookPayload = (raw: string): string => {
                        const trimmed = raw.trim();
                        if (!trimmed) return '';

                        if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
                          try {
                            const unquoted = JSON.parse(trimmed);
                            if (typeof unquoted === 'string') return unquoted.trim();
                          } catch {
                            // ignore
                          }
                        }

                        return trimmed;
                      };

                      const isValidEbookJsonArray = (raw: string): boolean => {
                        try {
                          const parsed = JSON.parse(raw);
                          return Array.isArray(parsed);
                        } catch {
                          return false;
                        }
                      };

                      const isEbookCommentsEffectivelyEmpty = (raw: string): boolean => {
                        try {
                          if (!raw || raw === '[]') return true;
                          const parsed = JSON.parse(raw);
                          if (!Array.isArray(parsed)) return true;
                          if (parsed.length === 0) return true;
                          return parsed.every((page: any) => Array.isArray(page) && page.length === 0);
                        } catch {
                          return true;
                        }
                      };

                      // Improved payload selection: find the LATEST payload that actually HAS content.
                      const bestEbookPayload = savedEbookHighlightPayloads
                        .slice()
                        .sort((a, b) => b.time - a.time)
                        .map((p) => normalizeEbookPayload(p.raw))
                        .find((p) => p.startsWith('[') && isValidEbookJsonArray(p) && !isEbookCommentsEffectivelyEmpty(p))
                        ?? savedEbookHighlightPayloads
                          .slice()
                          .sort((a, b) => b.time - a.time)
                          .map((p) => normalizeEbookPayload(p.raw))
                          .find((p) => p.startsWith('[') && isValidEbookJsonArray(p));

                      console.log('[IGNITE DEBUG] Best ebook payload selected. Length:', bestEbookPayload?.length || 0, 'isEmpty:', isEbookCommentsEffectivelyEmpty(bestEbookPayload || ''));

                      // Wait a bit for iframe content to fully load
                      setTimeout(() => {
                        const iframeDoc = iframeElement.contentDocument;
                        const iframeWin = iframeElement.contentWindow as any;

                        if (!iframeDoc || !iframeWin) {
                          console.warn('Cannot access iframe for content restoration');
                          return;
                        }

                        const runUpdateHighlightWithRetry = () => {
                          let attemptsLeft = 30; // Increased attempts
                          const tick = () => {
                            try {
                              // If the API isn't there yet, just return and wait for next tick
                              if (typeof iframeWin.UpdateHighlight !== 'function' && 
                                  typeof iframeWin.RecvHighDataFromLMS !== 'function') {
                                attemptsLeft -= 1;
                                if (attemptsLeft > 0) setTimeout(tick, 500);
                                return;
                              }

                              const leftPageNo = Number(iframeWin.AudConfig?.CurrPageNo ?? 1);
                              const rightPageNo = leftPageNo + 1;
                              const leftIframe = iframeDoc.querySelector(`#page${leftPageNo} > iframe`) as HTMLIFrameElement | null;
                              const rightIframe = iframeDoc.querySelector(`#page${rightPageNo} > iframe`) as HTMLIFrameElement | null;

                              const isInnerIframeReady = (ifr: HTMLIFrameElement | null): boolean => {
                                if (!ifr) return false;
                                try {
                                  const d = ifr.contentDocument;
                                  if (!d) return false;
                                  if (d.readyState !== 'complete') return false;
                                  if (!d.body) return false;
                                  if (d.body.childElementCount === 0) return false;
                                  return true;
                                } catch {
                                  return false;
                                }
                              };

                              const leftReady = isInnerIframeReady(leftIframe);
                              const rightReady = iframeWin.AudConfig?.BookLayout === 'magazine'
                                ? isInnerIframeReady(rightIframe)
                                : true;

                              if (leftReady && rightReady) {
                                // Call multiple times to survive late DOM updates within page iframes
                                if (typeof iframeWin.UpdateHighlight === 'function') {
                                  iframeWin.UpdateHighlight();
                                  setTimeout(() => {
                                    try { iframeWin.UpdateHighlight(); } catch {}
                                  }, 400);
                                  setTimeout(() => {
                                    try { iframeWin.UpdateHighlight(); } catch {}
                                  }, 900);
                                }
                                return;
                              }
                            } catch {
                              // ignore
                            }

                            attemptsLeft -= 1;
                            if (attemptsLeft <= 0) return;
                            setTimeout(tick, 300);
                          };
                          tick();
                        };

                        // 1) Restore Reader ebook highlights using its official APIs
                        if (bestEbookPayload && typeof bestEbookPayload === 'string') {
                          try {
                            const parsedPayload = JSON.parse(bestEbookPayload);
                            if (Array.isArray(parsedPayload) && typeof iframeWin.RecvHighDataFromLMS === 'function') {
                              console.log('[IGNITE] Restoring ebook highlights via RecvHighDataFromLMS');
                              iframeWin.RecvHighDataFromLMS(parsedPayload);
                              runUpdateHighlightWithRetry();
                            } else if (typeof iframeWin.FilterHighArrrFromLMS === 'function') {
                              console.log('[IGNITE] Restoring ebook highlights via FilterHighArrrFromLMS');
                              iframeWin.FilterHighArrrFromLMS(bestEbookPayload);
                              runUpdateHighlightWithRetry();
                            } else if (typeof iframeWin.RecComments === 'function') {
                              console.log('[IGNITE] Restoring ebook highlights via RecComments');
                              iframeWin.RecComments(bestEbookPayload);
                              if (typeof iframeWin.OnChapterSelRecComments === 'function') {
                                iframeWin.OnChapterSelRecComments();
                              }
                              runUpdateHighlightWithRetry();
                            } else if (typeof iframeWin.setComments === 'function') {
                              console.log('[IGNITE] Restoring ebook highlights via setComments');
                              iframeWin.setComments(bestEbookPayload);
                              runUpdateHighlightWithRetry();
                            } else {
                              console.warn('[IGNITE] Ebook highlight restore APIs not available yet');
                              // Still try to setup the retry polling in case APIs appear later
                              runUpdateHighlightWithRetry();
                            }
                          } catch (e) {
                            console.error('[IGNITE] Error restoring ebook highlight payload:', e);
                          }
                        } else {
                          if (savedEbookHighlightPayloads.length > 0) {
                            console.warn('[IGNITE] No valid ebook highlight payload found to restore');
                          }
                        }

                        // 2) Restore our custom event-based annotations (text coloring/comments)
                        savedCustomEvents.forEach((item) => {
                          try {
                            const contentData = JSON.parse(item.elementValue);

                            switch (contentData.type) {
                              case 'highlight':
                                restoreHighlight(iframeDoc, contentData);
                                break;
                              case 'text_coloring':
                                restoreTextColoring(iframeDoc, contentData);
                                break;
                              case 'comment':
                              case 'comment_final':
                                restoreComment(iframeDoc, contentData);
                                break;
                              case 'drawing':
                                console.log('Drawing data found:', contentData);
                                // Drawing restoration would need canvas-specific implementation
                                break;
                            }
                          } catch (parseError) {
                            console.error('Error parsing saved content:', parseError);
                          }
                        });

                        console.log('Content restoration completed');
                      }, 2000); // 2 second delay
                    }
                  } catch (error) {
                    console.error('Error restoring saved content:', error);
                  }
                };
                
                // Helper functions for restoration
                const restoreHighlight = (doc: Document, data: any) => {
                  console.log('Restoring highlight:', data);
                  // Find the text and apply highlighting
                  const walker = doc.createTreeWalker(
                    doc.body,
                    NodeFilter.SHOW_TEXT
                  );
                  
                  let node;
                  while (node = walker.nextNode()) {
                    if (node.textContent && node.textContent.includes(data.text)) {
                      const span = doc.createElement('span');
                      span.style.backgroundColor = 'yellow';
                      span.style.color = 'black';
                      span.textContent = data.text;
                      
                      const parent = node.parentNode;
                      if (parent) {
                        parent.replaceChild(span, node);
                        console.log('Highlight restored for:', data.text);
                        break;
                      }
                    }
                  }
                };
                
                const restoreTextColoring = (doc: Document, data: any) => {
                  console.log('Restoring text coloring:', data);
                  // Find elements with the specific text and apply color
                  const elements = doc.querySelectorAll('*');
                  elements.forEach(el => {
                    if (el.textContent && el.textContent.trim() === data.text) {
                      (el as HTMLElement).style.color = data.color;
                      if (data.backgroundColor && data.backgroundColor !== 'rgba(0, 0, 0, 0)') {
                        (el as HTMLElement).style.backgroundColor = data.backgroundColor;
                      }
                      console.log('Text coloring restored for:', data.text);
                    }
                  });
                };
                
                const restoreComment = (doc: Document, data: any) => {
                  console.log('Restoring comment:', data);
                  // Find the comment element by ID or create a new one
                  let commentElement = doc.querySelector(`#${data.elementId}`);
                  
                  if (!commentElement) {
                    // Try to find by data-id attribute
                    commentElement = doc.querySelector(`[data-id="${data.elementId}"]`);
                  }
                  
                  if (commentElement) {
                    if (commentElement.tagName === 'INPUT') {
                      (commentElement as HTMLInputElement).value = data.text;
                    } else if (commentElement.tagName === 'TEXTAREA') {
                      (commentElement as HTMLTextAreaElement).value = data.text;
                    } else {
                      commentElement.textContent = data.text;
                }
                console.log('Comment restored for element:', data.elementId);
              }
            };
            
            // Start restoration process
            restoreSavedContent();
            
            // Make the updateScormProgress function available globally for SCORM tracking
                (window as any).updateScormProgress = updateScormProgress;
              } catch (error) {
                console.error('Error setting up SCORM progress tracking:', error);
              }
              
              // Get the iframe's document
              const iframeDoc = iframeElement.contentDocument || (iframeElement.contentWindow as any)?.document;
              
              if (!iframeDoc) return;
              
              // Inject CSS to hide scrollbars completely
              const style = iframeDoc.createElement('style');
              style.textContent = `
                /* Hide all scrollbars completely */
                html {
                  overflow: -moz-scrollbars-none !important;
                  scrollbar-width: none !important;
                  -ms-overflow-style: none !important;
                }
                
                html::-webkit-scrollbar {
                  display: none !important;
                  width: 0 !important;
                  height: 0 !important;
                }
                
                body {
                  overflow: -moz-scrollbars-none !important;
                  scrollbar-width: none !important;
                  -ms-overflow-style: none !important;
                }
                
                body::-webkit-scrollbar {
                  display: none !important;
                  width: 0 !important;
                  height: 0 !important;
                }
                
                /* Hide scrollbars on all elements */
                *::-webkit-scrollbar {
                  display: none !important;
                  width: 0 !important;
                  height: 0 !important;
                }
                
                * {
                  scrollbar-width: none !important;
                  -ms-overflow-style: none !important;
                }
              `;
              iframeDoc.head.appendChild(style);
              
              // Inject LMSAPI bridge into iframe
              try {
                // First, inject early initialization script to prevent ArrHighltLMS errors
                const initScript = iframeDoc.createElement('script');
                initScript.textContent = `
                  // Initialize ArrHighltLMS early to prevent undefined errors
                  if (!window.ArrHighltLMS) {
                    window.ArrHighltLMS = [];
                  }
                  // Ensure all page slots have arrays (not undefined)
                  for (var i = 0; i < 50; i++) {
                    if (!window.ArrHighltLMS[i]) {
                      window.ArrHighltLMS[i] = [];
                    }
                  }
                  // Also initialize SendArrHighltLMS if needed
                  if (typeof window.SendArrHighltLMS === 'undefined') {
                    window.SendArrHighltLMS = '[]';
                  }
                  console.log('[IGNITE] ArrHighltLMS initialized with', window.ArrHighltLMS.length, 'pages');
                `;
                iframeDoc.head.appendChild(initScript);
                
                const script = iframeDoc.createElement('script');
                // Use full URL with correct port and base path
                script.src = `${window.location.origin}/oxfordignite/SCORMCoursePlayer/LMSAPIBridge.js`;
                script.onload = () => {
                  console.log('[SCORM] LMSAPI bridge loaded in iframe');
                };
                script.onerror = () => {
                  console.error('[SCORM] Failed to load LMSAPI bridge in iframe');
                  // Fallback: Create basic LMSAPI directly in iframe
                  const fallbackScript = iframeDoc.createElement('script');
                  fallbackScript.textContent = `
                    window.LMSAPI = window.LMSAPI || function() {
                      this.LMSInitialize = () => "true";
                      this.LMSGetValue = (elem) => "";
                      this.LMSSetValue = (elem, val) => {
                        if (window.parent.updateScormProgress) {
                          window.parent.updateScormProgress(elem, val);
                        }
                        return "true";
                      };
                      this.LMSCommit = () => "true";
                      this.LMSFinish = () => "true";
                      this.LMSGetLastError = () => "0";
                      return this;
                    };
                    window.lmsAPI = new window.LMSAPI();
                    console.log('[SCORM] Fallback LMSAPI created');
                  `;
                  iframeDoc.head.appendChild(fallbackScript);
                };
                iframeDoc.head.appendChild(script);
              } catch (error) {
                console.error('[SCORM] Error injecting LMSAPI bridge:', error);
              }
              
              // Set up MutationObserver to track style changes
              if (observerRef.current) {
                observerRef.current.disconnect();
              }
              
              observerRef.current = new MutationObserver(handleStyleChanges);
              
              try {
                // Start observing the document with the configured parameters
                observerRef.current.observe(iframeDoc.documentElement, {
                  attributes: true,
                  attributeFilter: ['style', 'class'],
                  childList: true,
                  subtree: true,
                  attributeOldValue: true
                });
              } catch (error) {
                console.error('Error setting up MutationObserver:', error);
              }
              
              try {
                // Ensure viewport is set correctly
                let viewportMeta = iframeDoc.querySelector('meta[name="viewport"]');
                if (!viewportMeta) {
                  viewportMeta = iframeDoc.createElement('meta');
                  viewportMeta.setAttribute('name', 'viewport');
                  iframeDoc.head.prepend(viewportMeta);
                }
                viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes');
                
                // Remove any duplicate styles or scripts
                const existingStyles = iframeDoc.querySelectorAll('style');
                existingStyles.forEach((style, index) => {
                  // Keep only the first style tag (the one we added in cleanHtmlContent)
                  if (index > 0) style.remove();
                });
                
                // Ensure body takes full height and has no margin/padding
                const body = iframeDoc.body;
                if (body) {
                  body.style.margin = '0';
                  body.style.padding = '0';
                  body.style.width = '100%';
                  body.style.height = '100%';
                  body.style.overflow = 'auto';
                }
              } catch (e) {
                console.warn('Could not modify iframe content:', e);
              }
            }}
            onError={(e) => {
              console.error('Error loading iframe content:', e);
              setError('Failed to load content. Please check the URL and try again.');
              setLoading(false);
            }}
          />
        </div>
      </div>
    );
  }

  // Handle PDF content
  return (
    <div
      className={`bg-white flex flex-col relative ${isFullscreen ? 'fixed inset-0 z-50' : ''} ${className} max-[768px]:${isFullscreen ? 'touch-pan-y' : ''}`}
      style={{
        ...(style || {}),
        ...(isFullscreen
          ? {}
          : {
              minHeight: 'calc(100vh - var(--app-header-height, 80px))',
            }),
      }}
    >
      {/* Content Area - Scrollable */}
      <div
        ref={containerRef}
        className={`pdf-scrollbar flex-1 bg-white-50 overflow-y-auto overflow-x-auto ${isFullscreen ? 'max-[768px]:touch-pan-y' : ''}`}
        style={isFullscreen ? {
          height: '100vh',
          maxHeight: '100vh',
          scrollBehavior: 'smooth',
          WebkitOverflowScrolling: 'touch'
        } : {}}
      >
        {loading ? (
          <div className="flex flex-col items-center justify-center h-full min-h-[400px]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
            <p className="text-gray-600 text-sm">Loading PDF...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center h-full min-h-[400px]">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        ) : (
          <div className={`flex flex-col ${isFullscreen ? 'min-h-full' : 'flex-1'}`}>
            {/* PDF Content */}
              <div className={`flex items-start justify-center p-4 relative ${isFullscreen ? 'overflow-visible min-h-full' : ''}`} style={isFullscreen ? undefined : { alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                <canvas
                  ref={canvasRef}
                  className={`border shadow-lg ${isFullscreen ? 'max-w-full' : ''}`}
                  style={isFullscreen ? {
                    maxWidth: '100%',
                    width: 'auto',
                    display: 'block',
                    margin: '0px auto',
                    position: 'relative',
                    height: 'auto',
                    top: 'auto',
                    overflow: 'visible',
                    touchAction: 'pan-y',
                    border: 'none',
                    boxShadow: 'none'
                  } : {
                    maxWidth: '100%',
                    width: 'auto', 
                    height: 'auto',
                    display: 'block',
                    margin: '0 auto',
                    position: 'relative',
                    top: 'auto',
                    overflow: 'visible'
                  }}
                  
                />
              </div>
          
            
            {!isHtml && (
                <>
                {isFullscreen ? (
                  // Fullscreen mode - Fixed bottom zoom controls
                  <div className="flex items-center justify-center space-x-3  p-4 mb-1" >
                    <div className="flex items-center space-x-1 w-fit bg-white/95 backdrop-blur-sm rounded-lg p-2 border border-gray-200 shadow-lg max-[480px]:p-1 max-[480px]:space-x-0.5" style={{bottom: '20px', position: 'relative'}}>
                        <Button
                          variant="ghost"
                          size="sm"
                          onTouchStart={handleZoomOut}
                          onTouchEnd={(e) => { e.preventDefault(); handleZoomOut(); }}
                          onClick={handleZoomOut}
                          disabled={scale <= 0.5}
                          className="h-8 w-8 p-0 hover:bg-blue-700 hover:text-white max-[480px]:h-6 max-[480px]:w-6 active:bg-blue-600 touch-manipulation"
                          title="Zoom Out"
                        >
                          <ZoomOut className="w-4 h-4" />
                        </Button>
                        
                        <span className="text-sm text-slate-600 font-semibold min-w-[45px] text-center select-none">
                          {Math.round(scale * 100)}%
                        </span>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onTouchStart={handleZoomIn}
                          onTouchEnd={(e) => { e.preventDefault(); handleZoomIn(); }}
                          onClick={handleZoomIn}
                          disabled={scale >= 2.50}
                          className="h-8 w-8 p-0 hover:bg-blue-700 hover:text-white max-[480px]:h-6 max-[480px]:w-6 active:bg-blue-600 touch-manipulation"
                          title="Zoom In"
                        >
                          <ZoomIn className="w-4 h-4" />
                        </Button>
                      </div>
                      </div>
                 
                ) : (  
                      <div className="flex items-center justify-center space-x-3 p-4 mb-2 max-[768px]:mb-0">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={goToPreviousPage}
                          disabled={currentPage <= 1}
                          className="bg-white hover:bg-blue-700 hover:text-white border-slate-200"
                        >
                          <ChevronLeft className="w-4 h-3 mr-1" />
                          Previous
                        </Button>
                        
                        <div className="flex items-center space-x-1 px-3 py-1 bg-white border border-slate-200 rounded-md">
                          <span className="text-sm text-slate-500 style={{fontWeight: '600'}}">
                            {currentPage} / {totalPages}
                          </span>
                        </div>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={goToNextPage}
                          disabled={currentPage >= totalPages}
                          className="bg-white hover:bg-blue-700 hover:text-white border-slate-200"
                        >
                          Next
                          <ChevronRight className="w-4 h-3 ml-1" />
                        </Button>

                              {/* Zoom Controls */}
                      <div className="flex items-center space-x-1 bg-white/80 rounded-lg p-1 border border-gray-200">
                        <Button
                          variant="ghost"
                          size="sm"
                          onTouchStart={handleZoomOut}
                          onTouchEnd={(e) => { e.preventDefault(); handleZoomOut(); }}
                          onClick={handleZoomOut}
                          disabled={scale <= 0.5}
                          className="h-6 w-6 p-0 hover:bg-blue-700 hover:text-white max-[480px]:h-6 max-[480px]:w-6 active:bg-blue-600 touch-manipulation"
                          title="Zoom Out"
                        >
                          <ZoomOut className="w-3 h-3" />
                        </Button>
                        
                        <span className="text-sm text-slate-600 font-semibold min-w-[45px] text-center select-none">
                          {Math.round(scale * 100)}%
                        </span>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onTouchStart={handleZoomIn}
                          onTouchEnd={(e) => { e.preventDefault(); handleZoomIn(); }}
                          onClick={handleZoomIn}
                          disabled={scale >= 2.75}
                          className="h-6 w-6 p-0 hover:bg-blue-700 hover:text-white max-[480px]:h-6 max-[480px]:w-6 active:bg-blue-600 touch-manipulation"
                          title="Zoom In"
                        >
                          <ZoomIn className="w-3 h-3" />
                        </Button>
                        
                      </div>
                      </div>
                   
                )}
                </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PDFViewer;
