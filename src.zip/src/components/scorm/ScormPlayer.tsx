import React, { useEffect, useRef, useState } from 'react';
import { useScorm } from './ScormProvider';
import { useScormService } from '@/services/scormService';

interface ScormPlayerProps {
  /**
   * URL to the SCORM package or content to be loaded
   */
  src: string;
  
  /**
   * Callback when SCORM content reports completion
   */
  onComplete?: (data: Record<string, any>) => void;
  
  /**
   * Callback when SCORM encounters an error
   */
  onError?: (error: Error) => void;
  
  /**
   * Additional class names for the container
   */
  className?: string;
  
  /**
   * If true, the player will automatically initialize SCORM when mounted
   */
  autoInitialize?: boolean;
}

/**
 * Enhanced SCORM Player component that loads and displays SCORM content
 * with improved tracking and progress management
 */
const ScormPlayer: React.FC<ScormPlayerProps> = ({
  src,
  onComplete,
  onError,
  className = '',
  autoInitialize = true,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { 
    isInitialized, 
    initializeScorm, 
    terminateScorm, 
    setScormValue, 
    getScormValue, 
    commitScormData 
  } = useScorm();
  
  const scormService = useScormService();
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Initialize SCORM when component mounts if autoInitialize is true
  useEffect(() => {
    if (autoInitialize && !isInitialized) {
      try {
        initializeScorm();
        console.log('[SCORM Player] SCORM initialized successfully');
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Failed to initialize SCORM');
        setError(error);
        onError?.(error);
        console.error('[SCORM Player] Initialization error:', error);
      }
    }

    // Cleanup on unmount
    return () => {
      if (isInitialized) {
        try {
          // Try to commit any pending data
          commitScormData();
          // Terminate the SCORM session
          terminateScorm();
          console.log('[SCORM Player] SCORM session terminated');
        } catch (err) {
          console.error('[SCORM Player] Error during SCORM cleanup:', err);
        }
      }
    };
  }, [autoInitialize, isInitialized]);

  // Handle iframe load event
  const handleIframeLoad = () => {
    setIsLoading(false);
    console.log('[SCORM Player] Iframe loaded successfully');
    
    // Check if we need to inject the SCORM API into the iframe
    if (iframeRef.current?.contentWindow) {
      try {
        // Inject SCORM API bridge into iframe
        const iframeDoc = iframeRef.current.contentDocument || (iframeRef.current.contentWindow as any)?.document;
        
        if (iframeDoc) {
          const script = iframeDoc.createElement('script');
          script.textContent = `
            // Create SCORM API bridge in iframe
            window.API = window.API || function() {
              this.LMSInitialize = () => "true";
              this.LMSGetValue = (element) => {
                // Get value from parent's SCORM service
                if (window.parent.scormService) {
                  return window.parent.scormService.getScormValue(element);
                }
                return "";
              };
              this.LMSSetValue = (element, value) => {
                // Set value using parent's SCORM service
                if (window.parent.scormService) {
                  return window.parent.scormService.setScormValue(element, value);
                }
                return "true";
              };
              this.LMSCommit = () => {
                // Commit using parent's SCORM service
                if (window.parent.scormService) {
                  return window.parent.scormService.commitScormData();
                }
                return "true";
              };
              this.LMSFinish = () => "true";
              this.LMSGetLastError = () => "0";
              this.LMSGetErrorString = (errorCode) => "No error";
              this.LMSGetDiagnostic = (errorCode) => "No diagnostic";
              return this;
            };
            
            // Initialize API instance
            window.API = new window.API();
            console.log('[SCORM Player] SCORM API bridge injected into iframe');
          `;
          iframeDoc.head.appendChild(script);
        }
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Failed to inject SCORM API');
        setError(error);
        onError?.(error);
        console.error('[SCORM Player] API injection error:', error);
      }
    }
  };

  // Handle errors loading the iframe
  const handleIframeError = (event: React.SyntheticEvent<HTMLIFrameElement>) => {
    const error = new Error('Failed to load SCORM content');
    setError(error);
    onError?.(error);
    setIsLoading(false);
    console.error('[SCORM Player] Iframe load error:', error);
  };

  // Listen for SCORM completion events
  useEffect(() => {
    if (!isInitialized) return;

    const checkCompletion = () => {
      try {
        const status = getScormValue('cmi.core.lesson_status');
        console.log('[SCORM Player] Checking completion status:', status);
        
        if (status === 'passed' || status === 'completed' || status === 'failed') {
          // Get completion data
          const completionData = {
            status,
            score: getScormValue('cmi.core.score.raw'),
            suspendData: getScormValue('cmi.suspend_data'),
            progress: getScormValue('cmi.core.progress_measure'),
            bookmark: getScormValue('cmi.core.lesson_location'),
            timestamp: new Date().toISOString()
          };
          
          console.log('[SCORM Player] Completion detected:', completionData);
          onComplete?.(completionData);
          
          // Commit any final data
          commitScormData();
        }
      } catch (err) {
        console.error('[SCORM Player] Error checking SCORM completion:', err);
      }
    };

    // Check completion every 5 seconds
    const interval = setInterval(checkCompletion, 5000);
    return () => clearInterval(interval);
  }, [isInitialized, getScormValue, commitScormData, onComplete]);

  // Set student name and initial status when SCORM is initialized
  useEffect(() => {
    if (isInitialized) {
      // Set student information
      const userName = sessionStorage.getItem('userName') || 'Student';
      scormService.setStudentName(userName);
      
      // Set initial status
      scormService.setStatus('incomplete');
      
      console.log('[SCORM Player] Student info and initial status set');
    }
  }, [isInitialized, scormService]);

  // Render loading state
  if (isLoading) {
    return (
      <div className={`scorm-loading flex items-center justify-center h-full ${className}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading SCORM content...</p>
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className={`scorm-error flex items-center justify-center h-full ${className}`}>
        <div className="text-center p-6">
          <h3 className="text-lg font-semibold text-red-600 mb-2">Error Loading SCORM Content</h3>
          <p className="text-gray-600 mb-4">{error.message}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // Render the SCORM content in an iframe
  return (
    <div className={`scorm-player w-full h-full ${className}`}>
      <iframe
        ref={iframeRef}
        src={src}
        title="SCORM Content"
        className="scorm-iframe w-full h-full border-0"
        onLoad={handleIframeLoad}
        onError={handleIframeError}
        allowFullScreen
        sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-presentation"
        style={{ 
          width: '100%', 
          height: '100%', 
          border: 'none',
          backgroundColor: 'white'
        }}
      />
    </div>
  );
};

export default ScormPlayer;
