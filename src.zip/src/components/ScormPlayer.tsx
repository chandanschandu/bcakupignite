import { useRef, useEffect, useState } from 'react';
import { attachHtmlTracking, trackPageView, trackCompletion } from '../scorm/ScormEventBridge';

interface ScormPlayerProps {
  src: string;
  width?: string | number;
  height?: string | number;
  className?: string;
  onProgress?: (progress: number) => void;
  onComplete?: () => void;
  onPageChange?: (page: string) => void;
}

export default function ScormPlayer({
  src,
  width = '100%',
  height = '600',
  className = '',
  onProgress,
  onComplete,
  onPageChange
}: ScormPlayerProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe) return;

    console.log('[SCORM PLAYER] Setting up SCORM player for:', src);

    // Set up tracking when iframe loads
    attachHtmlTracking(iframe);

    // Track initial page view
    trackPageView('start');

    return () => {
      // Cleanup if needed in the future
    };
  }, [src]);

  const handleIframeLoad = () => {
    console.log('[SCORM PLAYER] Iframe loaded successfully');
    setLoaded(true);
    setError('');
    
    // Track that content has loaded
    trackPageView('loaded');
  };

  const handleIframeError = () => {
    console.error('[SCORM PLAYER] Iframe failed to load');
    setError('Failed to load SCORM content');
    setLoaded(false);
  };

  if (error) {
    return (
      <div className={`flex items-center justify-center h-64 border border-red-300 bg-red-50 ${className}`}>
        <div className="text-center">
          <p className="text-red-600 style={{fontWeight: '600'}}">SCORM Content Error</p>
          <p className="text-red-500 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <p className="text-gray-600">Loading SCORM content...</p>
          </div>
        </div>
      )}
      
      <iframe
        ref={iframeRef}
        src={src}
        width={width}
        height={height}
        className="border-0"
        onLoad={handleIframeLoad}
        onError={handleIframeError}
        allowFullScreen
        sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-presentation"
        title="SCORM Content Player"
      />
    </div>
  );
}
