
// export default Footer;
import { Facebook, Youtube, Instagram, Linkedin } from "lucide-react";
import { useState, useRef, useEffect, useCallback } from "react";
import oxfordLogo from "@/assets/oxford-university-press-logo.png";

const Footer = ({ className = "" }: { className?: string }) => {
  const [popup, setPopup] = useState<"system" | "contact" | null>(null);
  const [popupStyle, setPopupStyle] = useState<React.CSSProperties>({});
  const popupRef = useRef<HTMLDivElement>(null);

  const systemRef = useRef<HTMLButtonElement>(null);
  const contactRef = useRef<HTMLButtonElement>(null);

  const openPopup = (type: "system" | "contact", ref: React.RefObject<HTMLButtonElement>) => {
    if (!ref.current) return;

    const rect = ref.current.getBoundingClientRect();
    const isMobile = window.innerWidth < 640;
    const popupHeight = isMobile ? 280 : 300;
    const popupWidth = isMobile ? Math.min(320, window.innerWidth - 32) : 350;
    const spaceAbove = rect.top;
    const spaceBelow = window.innerHeight - rect.bottom;
    const margin = 12;

    const centerX = rect.left + rect.width / 2;
    const leftPos = centerX - popupWidth / 2;
    const boundedLeft = Math.max(margin, Math.min(leftPos, window.innerWidth - popupWidth - margin));

    let verticalPos: React.CSSProperties = {};

    if (spaceAbove > popupHeight + margin && !isMobile) {
      verticalPos = { bottom: window.innerHeight - rect.top + margin };
    } else if (spaceBelow > popupHeight + margin) {
      verticalPos = { top: rect.bottom + margin };
    } else {
      if (spaceBelow > spaceAbove) {
        verticalPos = { top: rect.bottom + margin };
      } else {
        verticalPos = { bottom: window.innerHeight - rect.top + margin };
      }
    }

    const popupPosition: React.CSSProperties = {
      position: "fixed",
      left: boundedLeft,
      width: popupWidth,
      zIndex: 99999,
      ...verticalPos,
    };

    setPopupStyle(popupPosition);
    setPopup(type);
  };

  const closePopup = () => {
    setPopup(null);
    setPopupStyle({});
  };

  // SCROLL HANDLER - Auto close popup on ANY scroll (desktop + mobile)
  const handleScroll = useCallback(() => {
    if (popup) {
      closePopup();
    }
  }, [popup]);

  // CLICK OUTSIDE HANDLER
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        closePopup();
      }
    };

    if (popup) {
      document.addEventListener("mousedown", handleClickOutside);
      // ADD SCROLL LISTENERS FOR DESKTOP + MOBILE
      window.addEventListener("scroll", handleScroll, { passive: true });
      document.addEventListener("touchmove", handleScroll, { passive: true });
      
      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
        window.removeEventListener("scroll", handleScroll);
        document.removeEventListener("touchmove", handleScroll);
      };
    }
  }, [popup, handleScroll]);

  return (
    <footer
      className={`bg-[#002147] text-white w-full py-4 ${className}`}
      onClick={closePopup}
    >
      <div className="w-full px-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-4 max-[900px]:flex-col max-[900px]:items-start">
          {/* Logo */}
          <img src={oxfordLogo} alt="Oxford" className="h-11" />

          {/* Links */}
          <nav className="flex flex-wrap gap-3 text-sm flex-1">
            <a 
              href="https://global.oup.com/childrens-privacy-notice?cc=gb" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white text-sm sm:text-sm hover:text-gray-300 transition-colors "
            >
              Children Privacy Policy
            </a>
            <a 
              href="https://corp.oup.com/privacy-policy/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white text-sm sm:text-sm hover:text-gray-300 transition-colors "
            >
              Privacy Policy
            </a>
            <a 
              href="https://corp.oup.com/legal-notice" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white text-sm sm:text-sm hover:text-gray-300 transition-colors "
            >
              Legal Notice
            </a>
            <a 
              href="https://corp.oup.com/cookie-policy/"  
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white text-sm sm:text-sm hover:text-gray-300 transition-colors "
            >
              Cookies Policy
            </a>

            <button
              ref={systemRef}
              className="hover:text-gray-300 text-sm px-1 py-0.5 rounded focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-50"
              onMouseEnter={() => openPopup("system", systemRef)}
              onClick={() => openPopup("system", systemRef)}
            >
              System Requirements
            </button>

            <button
              ref={contactRef}
              className="hover:text-gray-300 text-sm px-1 py-0.5 rounded focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-50"
              onMouseEnter={() => openPopup("contact", contactRef)}
              onClick={() => openPopup("contact", contactRef)}
            >
              Contact Details
            </button>
          </nav>
          
          {/* Right */}
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <div>V: 1.0.0</div>
              <div> Oxford University Press | All rights reserved</div>
            </div>

            <div className="flex gap-2">
              <a href="https://www.facebook.com/OUPIndia" target="_blank" rel="noopener noreferrer"
                className="group w-8 h-8 md:w-10 md:h-10 rounded-full bg-white flex items-center justify-center hover:bg-[#1877F2] transition-all duration-300 transform hover:scale-105">
                <Facebook className="w-4 h-4 md:w-5 md:h-5 text-[#002147] group-hover:text-white transition-colors duration-300" />
              </a>
              <a href="https://www.youtube.com/@OUPIndia" target="_blank" rel="noopener noreferrer"
                className="group w-8 h-8 md:w-10 md:h-10 rounded-full bg-white flex items-center justify-center hover:bg-[#FF0000] transition-all duration-300 transform hover:scale-105">
                <Youtube className="w-4 h-4 md:w-5 md:h-5 text-[#002147] group-hover:text-white transition-colors duration-300" />
              </a>
              <a href="https://www.instagram.com/oxforduniversitypressin/" target="_blank" rel="noopener noreferrer"
                className="group w-8 h-8 md:w-10 md:h-10 rounded-full bg-white flex items-center justify-center hover:bg-gradient-to-br hover:from-purple-500 hover:via-pink-500 hover:to-orange-400 transition-all duration-300 transform hover:scale-105">
                <Instagram className="w-4 h-4 md:w-5 md:h-5 text-[#002147] group-hover:text-white transition-colors duration-300" />
              </a>
              <a href="https://www.linkedin.com/company/oxford-university-press-india/" target="_blank" rel="noopener noreferrer"
                className="group w-8 h-8 md:w-10 md:h-10 rounded-full bg-white flex items-center justify-center hover:bg-[#0A66C2] transition-all duration-300 transform hover:scale-105">
                <Linkedin className="w-4 h-4 md:w-5 md:h-5 text-[#002147] group-hover:text-white transition-colors duration-300" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* POPUP */}
      {popup && (
        <div 
          ref={popupRef}
          style={popupStyle}
          className="animate-in fade-in duration-200 slide-in-from-top-2"
          onMouseLeave={closePopup}
        >
          <div className="bg-white text-gray-800 p-4 rounded-lg shadow-2xl border border-gray-200 max-h-[70vh] overflow-y-auto">
            {popup === "system" && (
              <>
                <strong className="text-[#014880] block mb-2 text-sm font-semibold">Client System Requirements</strong>
                <hr className="border-gray-300 mb-3" />
                <table className="w-full text-xs sm:text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-1 font-semibold">Browser</th>
                      <th className="text-left py-1 font-semibold">Version</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-100">
                      <td className="py-1">Google Chrome</td>
                      <td className="py-1">45+</td>
                    </tr>
                    <tr className="border-b border-gray-100">
                      <td className="py-1">Mozilla Firefox</td>
                      <td className="py-1">30+</td>
                    </tr>
                    <tr>
                      <td className="py-1">Internet Explorer</td>
                      <td className="py-1">10+</td>
                    </tr>
                  </tbody>
                </table>
                <p className="text-xs sm:text-sm mt-3 text-gray-600 leading-relaxed">
                  *Best viewed with Desktop and Tablet.<br />
                  Minimum screen resolution 1024x768
                </p>
              </>
            )}

            {popup === "contact" && (
              <>
                <strong className="text-[#014880] block mb-2 text-sm font-semibold">Contact Information</strong>
                <hr className="border-gray-300 mb-4" />
                <div className="text-xs sm:text-sm space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-start gap-1">
                    <span className="font-semibold text-gray-800 min-w-[70px]">Address:</span>
                    <span className="text-gray-700 leading-relaxed">
                      Oxford University Press India, <br />
                      World Trade Tower, 12th Floor, <br />
                      C-1, Sec-16, Main DND Road, Rajnigandha Chowk, <br />
                      Noida - 201301
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-1">
                    <span className="font-semibold text-gray-800 min-w-[70px]">Email:</span>
                    <span className="text-gray-700">digitalhelp.in@oup.com</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-start gap-1">
                    <span className="font-semibold text-gray-800 min-w-[70px]">Toll Free:</span>
                    <span className="text-gray-700">
                      1800-4190-901 <br className="sm:hidden" />
                      <span className="text-xs sm:text-sm">(9:00 AM - 6:00 PM, Mon-Sat)</span>
                    </span>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </footer>
  );
};

export default Footer;
