var Config = {
	"home"			: "act1",		
	/*
	* Preload Images
	*/
	"preloadImages"	: [

		/*Common imgaes used*/
		"assets/images/loader.png",
		"assets/images/actResetBtn.png",
		"assets/images/actShowAnsBtn.png",
		"assets/images/actSubmitBtn.png",
		"assets/images/base.png",
		"assets/images/headerLabelBg.png",
		"assets/images/iconAud.png",
		"assets/images/optionBg.png",
		"assets/images/optionPoint1.png",
		"assets/images/optionPoint2.png",
		"assets/images/optionPoint3.png",

		/*activity images preload: change/add names below*/		
				
		// "assets/data/images/dragImg0.png",
		// "assets/data/images/dragImg1.png",
		// "assets/data/images/dragImg2.png",
		// "assets/data/images/dragImg3.png",
		// "assets/data/images/dragImg4.png",
		// "assets/data/images/dragImg5.png"																			
	]
};