import { trackScormElement, SCORM_2004_ELEMENTS } from './ScormTracker';
import { useScormService } from '@/services/scormService';

// Create a global SCORM service instance for the bridge
let scormServiceInstance: any = null;

export const setScormServiceInstance = (instance: any) => {
  scormServiceInstance = instance;
};

// Helper function to check if ebook comments data is effectively empty
const isEbookCommentsEmpty = (data: string): boolean => {
  try {
    if (!data || data === '[]') return true;
    const parsed = JSON.parse(data);
    if (!Array.isArray(parsed)) return true;
    if (parsed.length === 0) return true;
    // Check if all sub-arrays are empty (e.g., [[],[],[]])
    return parsed.every((page: any) => Array.isArray(page) && page.length === 0);
  } catch {
    return true;
  }
};

export const attachHtmlTracking = (iframe: HTMLIFrameElement) => {
  console.log('[SCORM EVENT BRIDGE] Setting up tracking for iframe');
  
  const doc = iframe.contentDocument;
  const win = iframe.contentWindow;
  const isReaderEbook = (() => {
    const w = win as any;
    return (
      typeof w?.FilterHighArrrFromLMS === 'function' ||
      typeof w?.RecComments === 'function' ||
      typeof w?.setComments === 'function' ||
      typeof w?.UpdateHighlight === 'function' ||
      (w && 'SendArrHighltLMS' in w) ||
      (w && 'ArrHighltLMS' in w)
    );
  })();

  const trackCustomEvent = (payload: any) => {
    if (isReaderEbook) return;
    const element = 'cmi.comments';
    trackScormElement(element, JSON.stringify(payload));
  };
  
  if (!doc || !win) {
    console.warn('[SCORM EVENT BRIDGE] Cannot access iframe content');
    return;
  }

  console.log('[SCORM EVENT BRIDGE] Iframe loaded, setting up event listeners');

  const styleCheckIntervals: NodeJS.Timeout[] = [];

  // For Reader ebook: keep cmi.comments reserved for ebook's own highlight persistence.
  // The ebook builds a JSON string in window.SendArrHighltLMS and normally writes it on unload.
  // In our SPA/iframe scenario unload is unreliable, so we periodically sync it.
  let lastSyncedEbookComments = '';
  let ebookCommentsSyncInterval: NodeJS.Timeout | null = null;
  if (isReaderEbook) {
    console.log('[SCORM EVENT BRIDGE] Reader ebook detected; reserving cmi.comments for ebook highlight persistence');
    
    // Defensively initialize ArrHighltLMS in the iframe's window object BEFORE the ebook loads
    try {
      if (!(win as any).ArrHighltLMS) {
        (win as any).ArrHighltLMS = [];
      }
      // Ensure all page slots have arrays (not undefined) - initialize up to 50 pages
      for (let i = 0; i < 50; i++) {
        if (!(win as any).ArrHighltLMS[i]) {
          (win as any).ArrHighltLMS[i] = [];
        }
      }
      console.log('[SCORM EVENT BRIDGE] Defensively initialized ArrHighltLMS with', (win as any).ArrHighltLMS.length, 'pages');
    } catch (e) {
      console.warn('[SCORM EVENT BRIDGE] Could not defensively initialize ArrHighltLMS:', e);
    }
    
    ebookCommentsSyncInterval = setInterval(() => {
      try {
        // Reader ebook builds a JSON string in window.SendArrHighltLMS
        // and sometimes uses window.ArrHighltLMS directly.
        const sendArr = (win as any).SendArrHighltLMS;
        const arrHighlt = (win as any).ArrHighltLMS;

        const ebookComments =
          typeof sendArr === 'string' && sendArr !== '[]' && sendArr.length > 2
            ? sendArr
            : Array.isArray(arrHighlt) && arrHighlt.length > 0
              ? JSON.stringify(arrHighlt)
              : sendArr === '[]' ? '[]' : '';

        if (!ebookComments || typeof ebookComments !== 'string') return;
        const trimmed = ebookComments.trim();
        if (!trimmed.startsWith('[')) return;
        
        // Skip sync if the data hasn't changed to avoid unnecessary API calls
        if (trimmed === lastSyncedEbookComments) return;

        // If ebookComments is effectively empty, skip sync ONLY if we have valid cached data to protect
        if (isEbookCommentsEmpty(trimmed)) {
          // Check our custom API for cached value
          const scormApi = (window as any).API || (window.parent && (window.parent as any).API);
          if (scormApi && typeof scormApi.GetValue === 'function') {
            const cached = scormApi.GetValue('cmi.comments');
            if (cached && !isEbookCommentsEmpty(cached)) {
              console.log('[SCORM EVENT BRIDGE] Skipping sync of empty ebook comments to protect cached data');
              // Update lastSyncedEbookComments to avoid repeated logging
              lastSyncedEbookComments = trimmed;
              return;
            }
          }
          // If we don't have cached data either, we still don't want to sync empty '[]' as it's often just init
          if (trimmed === '[]') return;
        }

        console.log('[SCORM EVENT BRIDGE] Valid highlight data detected from ebook, syncing...');

        if (typeof (win as any).setComments === 'function') {
          (win as any).setComments(trimmed);
        }

        try {
          // Sync to the central API
          const scormApi = (window as any).API || (window.parent && (window.parent as any).API);
          if (scormApi && typeof scormApi.SetValue === 'function') {
            scormApi.SetValue('cmi.comments', trimmed);
          }

          if (typeof (win as any).scorm?.save === 'function') {
            (win as any).scorm.save();
          } else if (typeof (win as any).pipwerks?.SCORM?.save === 'function') {
            (win as any).pipwerks.SCORM.save();
          }
        } catch (error) {
          // ignore
        }

        lastSyncedEbookComments = trimmed;
        console.log('[SCORM EVENT BRIDGE] Synced ebook highlights to cmi.comments');
      } catch (error) {
        // ignore
      }
    }, 5000);

    win.addEventListener('beforeunload', () => {
      try {
        if (typeof (win as any).endScorm === 'function') {
          (win as any).endScorm();
        }
      } catch (error) {
        // ignore
      }
    });
  }

  // Track word highlighting and text interactions
  const trackTextHighlighting = () => {
    try {
      console.log('[SCORM EVENT BRIDGE] Setting up enhanced text tracking');
      
      // Track text selection and highlighting
      doc.addEventListener('mouseup', (e) => {
        const selection = win.getSelection();
        if (selection && selection.toString().trim().length > 0) {
          const selectedText = selection.toString().trim();
          const targetElement = selection.anchorNode?.parentElement;
          
          // Exclude navigation elements from highlighting
          const isNavigationElement = 
            targetElement?.id?.toLowerCase().includes('next') ||
            targetElement?.id?.toLowerCase().includes('prev') ||
            targetElement?.id?.toLowerCase().includes('back') ||
            targetElement?.className?.toLowerCase().includes('nav') ||
            targetElement?.className?.toLowerCase().includes('button') ||
            targetElement?.tagName?.toLowerCase() === 'button' ||
            targetElement?.closest('nav') ||
            targetElement?.closest('[role="navigation"]');
          
          if (targetElement && selectedText.length < 200 && !isNavigationElement) { // Reasonable length and not navigation
            // Get page context
            const pageContext = getCurrentPageContext(doc);
            
            // Track highlighted text
            trackCustomEvent({
              type: 'highlight',
              text: selectedText,
              page: pageContext,
              element: targetElement.tagName.toLowerCase(),
              timestamp: new Date().toISOString(),
              position: {
                x: e.clientX,
                y: e.clientY
              }
            });
            
            console.log('[SCORM EVENT BRIDGE] Text highlighted:', selectedText, 'on page:', pageContext);
          }
        }
      });

        // Track all style changes more aggressively
        const styleObserver = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
            if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
              const target = mutation.target as HTMLElement;
              const computedStyle = win.getComputedStyle(target);
              const color = computedStyle.color;
              const backgroundColor = computedStyle.backgroundColor;
              const textContent = target.textContent?.trim() || '';
              
              // Check if this is a meaningful text element with content
              if (textContent.length > 0 && textContent.length < 200) {
                // Track any style change on text elements (more sensitive)
                const hasStyleChange = 
                  color !== 'rgb(0, 0, 0)' || 
                  backgroundColor !== 'rgba(0, 0, 0, 0)' && backgroundColor !== 'transparent' ||
                  target.style.color !== '' ||
                  target.style.backgroundColor !== '' ||
                  target.style.fontWeight !== '' ||
                  target.style.textDecoration !== '';
                
                if (hasStyleChange) {
                  const pageContext = getCurrentPageContext(doc);
                  const commentData = {
                    type: 'text_coloring',
                    text: textContent,
                    color: color || target.style.color || 'default',
                    backgroundColor: backgroundColor || target.style.backgroundColor || 'default',
                    fontWeight: target.style.fontWeight || 'default',
                    textDecoration: target.style.textDecoration || 'default',
                    page: pageContext,
                    element: target.tagName.toLowerCase(),
                    elementId: target.id || target.getAttribute('data-id') || '',
                    timestamp: new Date().toISOString()
                  };
                  
                  // Use filtered tracking if available, otherwise fallback to direct tracking
                  if (!isReaderEbook && scormServiceInstance && scormServiceInstance.trackComment) {
                    console.log('[SCORM EVENT BRIDGE] Using filtered tracking for:', commentData.text?.substring(0, 50));
                    scormServiceInstance.trackComment(commentData);
                  } else {
                    console.log('[SCORM EVENT BRIDGE] Using direct tracking (service not available)');
                    trackCustomEvent(commentData);
                  }
                  
                  console.log('[SCORM EVENT BRIDGE] Text styled:', textContent, 'color:', color, 'bg:', backgroundColor, 'weight:', target.style.fontWeight, 'on page:', pageContext);
                }
              }
            }
          });
        });

        // Track all text elements for style changes
        const textElements = doc.querySelectorAll('p, span, div, h1, h2, h3, h4, h5, h6, strong, em, b, i, u');
        console.log('[SCORM EVENT BRIDGE] Found', textElements.length, 'text elements to monitor');
        
        textElements.forEach(el => {
          styleObserver.observe(el, { 
            attributes: true, 
            attributeFilter: ['style', 'class'],
            subtree: true,
            characterData: true
          });
          
          // Store original values for comparison
          const element = el as HTMLElement;
          element.setAttribute('data-original-class', element.className);
          element.setAttribute('data-original-style', element.style.cssText);
          
          // Add event listeners for immediate change detection
          element.addEventListener('DOMAttrModified', (e) => {
            console.log('[SCORM EVENT BRIDGE] DOM attribute modified event detected');
            handleStyleChange(element, win, doc, isReaderEbook, scormServiceInstance, trackCustomEvent);
          });
          
          element.addEventListener('DOMSubtreeModified', (e) => {
            console.log('[SCORM EVENT BRIDGE] DOM subtree modified event detected');
            handleStyleChange(element, win, doc, isReaderEbook, scormServiceInstance, trackCustomEvent);
          });
        });

        // Helper function to handle style changes
        const handleStyleChange = (element: HTMLElement, win: Window, doc: Document, isReaderEbook: boolean, scormServiceInstance: any, trackCustomEvent: Function) => {
          const currentStyle = element.style.cssText;
          const currentClass = element.className;
          const originalStyle = element.getAttribute('data-original-style');
          const originalClass = element.getAttribute('data-original-class');
          
          // Only proceed if there are actual changes
          if (currentStyle !== originalStyle || currentClass !== originalClass) {
            const computedStyle = win.getComputedStyle(element);
            const textContent = element.textContent?.trim() || '';
            
            if (textContent.length > 0 && textContent.length < 200) {
              const pageContext = getCurrentPageContext(doc);
              const commentData = {
                type: 'text_coloring',
                text: textContent,
                color: computedStyle.color,
                backgroundColor: computedStyle.backgroundColor,
                fontWeight: computedStyle.fontWeight,
                textDecoration: computedStyle.textDecoration,
                fontStyle: computedStyle.fontStyle,
                classes: currentClass,
                page: pageContext,
                element: element.tagName.toLowerCase(),
                elementId: element.id || element.getAttribute('data-id') || '',
                timestamp: new Date().toISOString()
              };
              
              // Use filtered tracking if available, otherwise fallback to direct tracking
              if (!isReaderEbook && scormServiceInstance && scormServiceInstance.trackComment) {
                console.log('[SCORM EVENT BRIDGE] Using filtered tracking for:', commentData.text?.substring(0, 50));
                scormServiceInstance.trackComment(commentData);
              } else {
                console.log('[SCORM EVENT BRIDGE] Using direct tracking (service not available)');
                trackCustomEvent(commentData);
              }
              
              console.log('[SCORM EVENT BRIDGE] Text color changed:', textContent, 'color:', computedStyle.color, 'bg:', computedStyle.backgroundColor, 'classes:', currentClass, 'on page:', pageContext);
              
              // Update original values
              element.setAttribute('data-original-class', currentClass);
              element.setAttribute('data-original-style', currentStyle);
            }
          }
        };

        // Track input changes and interactions
        const inputElements = doc.querySelectorAll('input[type="text"], textarea, [contenteditable="true"]');
        console.log('[SCORM EVENT BRIDGE] Found', inputElements.length, 'input elements to monitor');
        
        inputElements.forEach(input => {
          const element = input as HTMLElement;
          
          // Track input changes
          element.addEventListener('input', (e) => {
            const target = e.target as HTMLElement;
            const comment = target.textContent?.trim() || (target as HTMLInputElement).value?.trim() || '';
            
            if (comment.length > 0) {
              const pageContext = getCurrentPageContext(doc);
              const elementId = target.id || target.getAttribute('data-id') || `input_${Date.now()}`;
              
              trackCustomEvent({
                type: 'comment_input',
                text: comment,
                page: pageContext,
                elementId: elementId,
                element: target.tagName.toLowerCase(),
                timestamp: new Date().toISOString()
              });
              
              console.log('[SCORM EVENT BRIDGE] Input changed:', comment, 'on page:', pageContext);
            }
          });
          
          // Track when user finishes editing
          element.addEventListener('blur', (e) => {
            const target = e.target as HTMLElement;
            const comment = target.textContent?.trim() || (target as HTMLInputElement).value?.trim() || '';
            
            if (comment.length > 0) {
              const pageContext = getCurrentPageContext(doc);
              const elementId = target.id || target.getAttribute('data-id') || `input_${Date.now()}`;
              
              trackCustomEvent({
                type: 'comment_final',
                text: comment,
                page: pageContext,
                elementId: elementId,
                element: target.tagName.toLowerCase(),
                timestamp: new Date().toISOString()
              });
              
              console.log('[SCORM EVENT BRIDGE] Comment finalized:', comment, 'on page:', pageContext);
            }
          });
        });

        // Track click events on any text element (exclude navigation and buttons)
        doc.addEventListener('click', (e) => {
          const target = e.target as HTMLElement;
          const textContent = target.textContent?.trim() || '';
          
          // Exclude navigation elements and buttons
          const isNavigationElement = 
            target.id?.toLowerCase().includes('next') ||
            target.id?.toLowerCase().includes('prev') ||
            target.id?.toLowerCase().includes('back') ||
            target.className?.toLowerCase().includes('nav') ||
            target.className?.toLowerCase().includes('button') ||
            target.tagName?.toLowerCase() === 'button' ||
            target.closest('nav') ||
            target.closest('[role="navigation"]');
          
          // Only track text elements that are not navigation
          if (!isNavigationElement && textContent.length > 0 && textContent.length < 100) {
            const pageContext = getCurrentPageContext(doc);
            
            trackCustomEvent({
              type: 'text_click',
              text: textContent,
              page: pageContext,
              element: target.tagName.toLowerCase(),
              elementId: target.id || target.getAttribute('data-id') || '',
              timestamp: new Date().toISOString(),
              position: {
                x: e.clientX,
                y: e.clientY
              }
            });
            
            console.log('[SCORM EVENT BRIDGE] Text clicked:', textContent, 'on page:', pageContext);
          }
        });

      } catch (error) {
        console.error('[SCORM EVENT BRIDGE] Error tracking text highlighting:', error);
      }
    };

    // Helper function to get current page context
    const getCurrentPageContext = (doc: Document) => {
      // Try multiple methods to determine current page
      const pageIndicators = [
        doc.querySelector('[class*="page active"]'),
        doc.querySelector('[class*="page current"]'),
        doc.querySelector('[data-current="true"]'),
        doc.querySelector('.page-number'),
        doc.querySelector('#page-number')
      ];
      
      for (const indicator of pageIndicators) {
        if (indicator) {
          return indicator.textContent?.trim() || 
                 indicator.getAttribute('data-page');
        }
      }
      
      // Fallback: check URL hash or query params
      if (win.location.hash) {
        return win.location.hash.replace('#', '');
      }
      
      return ''; // No hardcoded fallback
    };

    // Track page navigation and progress
    const trackPageProgress = () => {
      try {
        // Look for page indicators in the content
        const pageElements = doc.querySelectorAll('[class*="page"], [id*="page"], [data-page]');
        const currentPage = Array.from(pageElements).find(el => 
          el.classList.contains('active') || 
          el.classList.contains('current') ||
          el.getAttribute('data-current') === 'true'
        );
        
        if (currentPage) {
          const pageNum = currentPage.getAttribute('data-page') || 
                        currentPage.textContent?.match(/\d+/)?.[0];
          if (pageNum) {
            trackPageView(`page_${pageNum}`);
          }
        }
      } catch (error) {
        console.error('[SCORM EVENT BRIDGE] Error tracking page progress:', error);
      }
    };

    // Track quiz and assessment interactions
    const handleQuizInteraction = (e: Event) => {
      const target = e.target as HTMLElement;
      
      // Look for quiz questions and answers
      const questionContainer = target.closest('[class*="question"], [class*="quiz"], [class*="assessment"]');
      if (questionContainer) {
        const questionId = questionContainer.getAttribute('data-id') || 
                          questionContainer.getAttribute('id') || 
                          `question_${Date.now()}`;
        
        let answer = '';
        let responseType = 'choice';
        
        if (target.tagName === 'INPUT') {
          const input = target as HTMLInputElement;
          if (input.type === 'radio' || input.type === 'checkbox') {
            answer = input.value || input.checked ? 'selected' : 'not_selected';
            responseType = input.type === 'radio' ? 'choice' : 'true-false';
          } else if (input.type === 'text') {
            answer = input.value;
            responseType = 'fill-in';
          }
        } else if (target.tagName === 'SELECT') {
          const select = target as HTMLSelectElement;
          answer = select.value;
          responseType = 'choice';
        } else if (target.tagName === 'TEXTAREA') {
          answer = (target as HTMLTextAreaElement).value;
          responseType = 'fill-in';
        } else {
          answer = target.textContent || target.getAttribute('data-answer') || 'clicked';
        }
        
        if (answer) {
          console.log('[SCORM EVENT BRIDGE] Quiz interaction:', questionId, answer, responseType);
          trackInteraction(questionId, responseType, answer, 'neutral');
        }
      }
    };

    // Track navigation clicks
    const handleNavigation = (e: Event) => {
      const target = e.target as HTMLElement;
      const link = target.closest('a, button, [onclick]');
      
      if (link) {
        const href = link.getAttribute('href') || link.getAttribute('data-href') || '';
        const text = link.textContent?.trim() || '';
        
        // Track different types of navigation
        if (href.includes('next') || text.toLowerCase().includes('next')) {
          trackPageView('next_page');
        } else if (href.includes('prev') || text.toLowerCase().includes('prev')) {
          trackPageView('previous_page');
        } else if (href.includes('home') || text.toLowerCase().includes('home')) {
          trackPageView('home');
        } else if (href.includes('complete') || text.toLowerCase().includes('complete')) {
          trackCompletion('completed');
        } else if (href) {
          trackPageView(`navigation_${href.replace(/[^a-zA-Z0-9]/g, '_')}`);
        }
      }
    };

    // Track media interactions
    const handleMediaInteraction = (e: Event) => {
      const media = e.target as HTMLMediaElement;
      
      if (media.tagName === 'VIDEO' || media.tagName === 'AUDIO') {
        const currentTime = Math.floor(media.currentTime);
        const duration = Math.floor(media.duration);
        const progress = duration > 0 ? Math.round((currentTime / duration) * 100) : 0;
        
        // Track progress every 25%
        if (progress % 25 === 0) {
          const elementName = `cmi.progress_measure`;
          console.log('[SCORM EVENT BRIDGE] Media progress:', progress + '%');
          trackScormElement(elementName, (progress / 100).toString());
        }
      }
    };

    // Track form submissions
    const handleFormSubmit = (e: Event) => {
      const form = e.target as HTMLFormElement;
      const formData = new FormData(form);
      
      // Convert form data to SCORM elements
      for (const [key, value] of formData.entries()) {
        const elementName = `cmi.interactions.${key}.learner_response`;
        trackScormElement(elementName, value.toString());
      }
      
      // Track completion
      trackCompletion('completed');
    };

    // Track comments and annotations
    const trackComments = () => {
      try {
        // Track input fields for comments
        const commentInputs = doc.querySelectorAll('input[type="text"], textarea, [contenteditable="true"]');
        
        commentInputs.forEach(input => {
          const element = input as HTMLElement;
          
          // Track when user adds/edits comments
          element.addEventListener('input', (e) => {
            const target = e.target as HTMLElement;
            const comment = target.textContent?.trim() || (target as HTMLInputElement).value?.trim() || '';
            
            if (comment.length > 0) {
              const pageContext = getCurrentPageContext(doc);
              const elementId = target.id || target.getAttribute('data-id') || `comment_${Date.now()}`;
              
              trackCustomEvent({
                type: 'comment',
                text: comment,
                page: pageContext,
                elementId: elementId,
                element: target.tagName.toLowerCase(),
                timestamp: new Date().toISOString()
              });
              
              console.log('[SCORM EVENT BRIDGE] Comment added:', comment, 'on page:', pageContext);
            }
          });
          
          // Track when user finishes editing (blur event)
          element.addEventListener('blur', (e) => {
            const target = e.target as HTMLElement;
            const comment = target.textContent?.trim() || (target as HTMLInputElement).value?.trim() || '';
            
            if (comment.length > 0) {
              const pageContext = getCurrentPageContext(doc);
              const elementId = target.id || target.getAttribute('data-id') || `comment_${Date.now()}`;
              
              trackCustomEvent({
                type: 'comment_final',
                text: comment,
                page: pageContext,
                elementId: elementId,
                element: target.tagName.toLowerCase(),
                timestamp: new Date().toISOString()
              });
              
              console.log('[SCORM EVENT BRIDGE] Comment finalized:', comment, 'on page:', pageContext);
            }
          });
        });

        // Track drawing/annotation tools
        const canvasElements = doc.querySelectorAll('canvas');
        canvasElements.forEach(canvas => {
          canvas.addEventListener('mouseup', (e) => {
            const pageContext = getCurrentPageContext(doc);
            const canvasId = canvas.id || `canvas_${Date.now()}`;
            
            trackCustomEvent({
              type: 'drawing',
              page: pageContext,
              elementId: canvasId,
              element: 'canvas',
              timestamp: new Date().toISOString(),
              position: {
                x: e.offsetX,
                y: e.offsetY
              }
            });
            
            console.log('[SCORM EVENT BRIDGE] Drawing activity on canvas:', canvasId, 'page:', pageContext);
          });
        });

      } catch (error) {
        console.error('[SCORM EVENT BRIDGE] Error tracking comments:', error);
      }
    };

    // Initialize all tracking
    trackTextHighlighting();
    trackComments();
    trackPageProgress();

    // Add event listeners
    doc.addEventListener('change', handleQuizInteraction);
    doc.addEventListener('click', handleNavigation);
    doc.addEventListener('click', handleQuizInteraction);
    doc.addEventListener('timeupdate', handleMediaInteraction);
    doc.addEventListener('ended', (e) => {
      const media = e.target as HTMLMediaElement;
      if (media.tagName === 'VIDEO' || media.tagName === 'AUDIO') {
        trackCompletion('completed');
      }
    });
    doc.addEventListener('submit', handleFormSubmit);

    // Set up periodic page tracking
    const progressInterval = setInterval(trackPageProgress, 5000); // Check every 5 seconds

    // Track initial page load
    trackPageView('page_1');
    trackScormElement('cmi.entry', 'ab-initio');

    console.log('[SCORM EVENT BRIDGE] All event listeners attached');

    // Cleanup function
    return () => {
      clearInterval(progressInterval);

      if (ebookCommentsSyncInterval) {
        clearInterval(ebookCommentsSyncInterval);
        ebookCommentsSyncInterval = null;
      }
      
      // Clear all style check intervals
      styleCheckIntervals.forEach(interval => clearInterval(interval));
      
      doc.removeEventListener('change', handleQuizInteraction);
      doc.removeEventListener('click', handleNavigation);
      doc.removeEventListener('click', handleQuizInteraction);
      doc.removeEventListener('timeupdate', handleMediaInteraction);
      doc.removeEventListener('submit', handleFormSubmit);
      console.log('[SCORM EVENT BRIDGE] Event listeners removed');
    };
  };

  console.log('[SCORM EVENT BRIDGE] All event listeners attached');


export const trackPageView = (pageName: string) => {
  console.log('[SCORM EVENT BRIDGE] Page view:', pageName);
  trackScormElement('cmi.location', pageName);
};

export const trackCompletion = (status: 'completed' | 'incomplete' | 'failed' = 'completed') => {
  console.log('[SCORM EVENT BRIDGE] Completion status:', status);
  trackScormElement('cmi.completion_status', status);
  trackScormElement('cmi.success_status', status === 'completed' ? 'passed' : status);
};

export const trackScore = (score: number, maxScore: number = 100) => {
  console.log('[SCORM EVENT BRIDGE] Score:', score, '/', maxScore);
  trackScormElement('cmi.score.raw', score.toString());
  trackScormElement('cmi.score.max', maxScore.toString());
  trackScormElement('cmi.score.min', '0');
  trackScormElement('cmi.score.scaled', (score / maxScore).toString());
};

export const trackInteraction = (
  id: string, 
  type: string, 
  response: string, 
  result: 'correct' | 'incorrect' | 'neutral' = 'neutral'
) => {
  console.log('[SCORM EVENT BRIDGE] Interaction:', id, type, response, result);
  trackScormElement(`cmi.interactions.${id}.id`, id);
  trackScormElement(`cmi.interactions.${id}.type`, type);
  trackScormElement(`cmi.interactions.${id}.learner_response`, response);
  trackScormElement(`cmi.interactions.${id}.result`, result);
  trackScormElement(`cmi.interactions.${id}.timestamp`, new Date().toISOString());
};
