import { sendScormData } from '../services/scormService';

const elementCache: Record<string, string> = {};
const debounceTimers: Record<string, NodeJS.Timeout> = {};

export const trackScormElement = async (
  element: string,
  value: string
) => {
  // Enhanced logging for debugging
  console.log('[SCORM TRACK] Received:', { element, value, cached: elementCache[element] });
  
  // Skip if value hasn't changed
  if (elementCache[element] === value) {
    console.log('[SCORM TRACK] Skipping duplicate:', element, value);
    return;
  }

  // Update cache immediately
  elementCache[element] = value;

  // Clear existing debounce timer for this element
  if (debounceTimers[element]) {
    clearTimeout(debounceTimers[element]);
  }

  const debounceDelayMs = element === 'cmi.comments' ? 0 : 1000;

  // Debounce to prevent rapid API calls (disabled for cmi.comments)
  debounceTimers[element] = setTimeout(async () => {
    console.log('[SCORM TRACK] Sending to API:', element, value);
    try {
      await sendScormData(element, value);
      console.log('[SCORM TRACK] API call successful');
    } catch (error) {
      console.error('[SCORM TRACK] API call failed:', error);
    }
    
    // Clean up timer
    delete debounceTimers[element];
  }, debounceDelayMs);
};

export const clearScormCache = () => {
  // Clear element cache
  Object.keys(elementCache).forEach(key => delete elementCache[key]);
  
  // Clear debounce timers
  Object.values(debounceTimers).forEach(timer => clearTimeout(timer));
  Object.keys(debounceTimers).forEach(key => delete debounceTimers[key]);
  
  console.log('[SCORM TRACK] Cache and timers cleared');
};

// Listen for global clearScormCache events
if (typeof window !== 'undefined') {
  window.addEventListener('clearScormCache', () => {
    console.log('[SCORM TRACK] Global clearScormCache event received');
    clearScormCache();
  });
}

export const getCachedValue = (element: string): string | undefined => {
  return elementCache[element];
};

export const hydrateCachedValue = (element: string, value: string) => {
  elementCache[element] = value;
  console.log('[SCORM TRACK] Hydrated cache:', { element, valueLength: value?.length ?? 0 });
};

// Common SCORM 2004 elements
export const SCORM_2004_ELEMENTS = {
  COMPLETION_STATUS: 'cmi.completion_status',
  SUCCESS_STATUS: 'cmi.success_status', 
  SCORE_RAW: 'cmi.score.raw',
  SCORE_MIN: 'cmi.score.min',
  SCORE_MAX: 'cmi.score.max',
  SCORE_SCALED: 'cmi.score.scaled',
  PROGRESS_MEASURE: 'cmi.progress_measure',
  SESSION_TIME: 'cmi.session_time',
  TOTAL_TIME: 'cmi.total_time',
  ENTRY: 'cmi.entry',
  EXIT: 'cmi.exit',
  LOCATION: 'cmi.location',
  MODE: 'cmi.mode',
  INTERACTIONS: 'cmi.interactions',
  OBJECTIVES: 'cmi.objectives',
  STUDENT_NAME: 'cmi.learner_name',
  STUDENT_ID: 'cmi.learner_id',
  CREDIT: 'cmi.credit',
  LESSON_STATUS: 'cmi.completion_status', // Legacy support
  CORE_LESSON_STATUS: 'cmi.core.lesson_status' // SCORM 1.2
};

// Common SCORM values
export const SCORM_VALUES = {
  COMPLETED: 'completed',
  INCOMPLETE: 'incomplete',
  NOT_ATTEMPTED: 'not attempted',
  UNKNOWN: 'unknown',
  PASSED: 'passed',
  FAILED: 'failed',
  NORMAL: 'normal',
  REVIEW: 'review',
  BROWSE: 'browse',
  AB_INITIO: 'ab-initio',
  RESUME: 'resume',
  TIME_OUT: 'time-out',
  SUSPEND: 'suspend',
  LOGOUT: 'logout'
};
