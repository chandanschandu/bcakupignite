import { trackScormElement, SCORM_2004_ELEMENTS, SCORM_VALUES, getCachedValue } from './ScormTracker';

class ScormAPI {
  LMSInitialize(_param: string = '') {
    return this.Initialize();
  }

  Initialize() {
    console.log('[SCORM] Initialize');
    // Track initialization
    trackScormElement('cmi.entry', SCORM_VALUES.AB_INITIO);
    return 'true';
  }

  LMSGetValue(element: string) {
    return this.GetValue(element);
  }

  GetValue(element: string) {
    console.log('[SCORM] GetValue:', element);

    // For ebook highlights we store a potentially large JSON array in cmi.comments.
    // On refresh we rely on backend hydration into the in-memory cache.
    if (element === 'cmi.comments') {
      const cached = getCachedValue('cmi.comments');
      if (typeof cached === 'string') {
        const trimmed = cached.trim();
        if (!trimmed) return '[]';
        // Reader expects a JSON array string. Never return invalid JSON.
        if (trimmed.startsWith('[')) {
          try {
            const parsed = JSON.parse(trimmed);
            if (Array.isArray(parsed)) return trimmed;
          } catch {
            // ignore
          }
        }
      }
      return '[]';
    }

    const cached = getCachedValue(element);
    return cached ?? '';
  }

  LMSSetValue(element: string, value: string) {
    return this.SetValue(element, value);
  }

  SetValue(element: string, value: string) {
    console.log('[SCORM] SetValue:', element, '=', value);

    if (element === 'cmi.comments') {
      const cached = getCachedValue('cmi.comments');
      const incoming = typeof value === 'string' ? value.trim() : '';
      const existing = typeof cached === 'string' ? cached.trim() : '';

      // If the ebook tries to initialize cmi.comments with an empty array during load,
      // but we already have hydrated backend highlights in cache, ignore the empty overwrite.
      // We also check for effectively empty arrays like [[],[],[]]
      const isEffectivelyEmpty = (str: string) => {
        try {
          if (!str || str === '[]') return true;
          const parsed = JSON.parse(str);
          if (!Array.isArray(parsed)) return false;
          if (parsed.length === 0) return true;
          return parsed.every(p => Array.isArray(p) && p.length === 0);
        } catch {
          return false;
        }
      };

      const hasContent = (str: string) => {
        try {
          if (!str || str === '[]') return false;
          const parsed = JSON.parse(str);
          if (!Array.isArray(parsed)) return false;
          return parsed.some(p => Array.isArray(p) && p.length > 0);
        } catch {
          return false;
        }
      };

      if (isEffectivelyEmpty(incoming) && hasContent(existing)) {
        console.log('[SCORM] Ignoring cmi.comments overwrite with empty array/data');
        return 'true';
      }
    }

    trackScormElement(element, value);
    return 'true';
  }

  LMSCommit(_param: string = '') {
    return this.Commit();
  }

  Commit() {
    console.log('[SCORM] Commit');
    return 'true';
  }

  LMSFinish(_param: string = '') {
    return this.Terminate();
  }

  Terminate() {
    console.log('[SCORM] Terminate');
    // Track termination
    trackScormElement('cmi.exit', SCORM_VALUES.LOGOUT);
    return 'true';
  }

  GetLastError() {
    return '0';
  }

  LMSGetLastError() {
    return this.GetLastError();
  }

  GetErrorString(errorCode: string) {
    return 'No error';
  }

  LMSGetErrorString(errorCode: string) {
    return this.GetErrorString(errorCode);
  }

  GetDiagnostic(errorCode: string) {
    return 'No diagnostic';
  }

  LMSGetDiagnostic(errorCode: string) {
    return this.GetDiagnostic(errorCode);
  }
}

// SCORM 2004 API
class Scorm2004API extends ScormAPI {
  Initialize() {
    console.log('[SCORM 2004] Initialize');
    trackScormElement('cmi.entry', SCORM_VALUES.AB_INITIO);
    return 'true';
  }

  SetValue(element: string, value: string) {
    console.log('[SCORM 2004] SetValue:', element, '=', value);
    trackScormElement(element, value);
    return 'true';
  }

  Terminate() {
    console.log('[SCORM 2004] Terminate');
    trackScormElement('cmi.exit', SCORM_VALUES.LOGOUT);
    return 'true';
  }
}

// Create API instances
const scorm12Api = new ScormAPI();
const scorm2004Api = new Scorm2004API();

// Expose globally for iframe SCORM content
if (typeof window !== 'undefined') {
  (window as any).API = scorm12Api;        // SCORM 1.2
  (window as any).API_1484_11 = scorm2004Api; // SCORM 2004
  
  console.log('[SCORM] APIs exposed globally:', {
    'API': 'SCORM 1.2',
    'API_1484_11': 'SCORM 2004'
  });
}

export { scorm12Api, scorm2004Api };
