export type ScormElement = {
  element: string;
  value: string;
  timestamp: number;
};

export type ScormProgressData = {
  UserID: number;
  CourseAssetID: number;
  CSAssetID: number;
  IsInsert: boolean;
  ElementName: string;
  ElementValue: string;
  CourseId: number;
  ScheduleUserDetailID: number;
};

export type ScormInteraction = {
  id: string;
  type: 'true-false' | 'choice' | 'fill-in' | 'matching' | 'performance' | 'sequencing' | 'likert' | 'numeric';
  objectives?: string[];
  correct_responses?: string[];
  student_response?: string;
  result?: 'correct' | 'incorrect' | 'neutral' | 'unanticipated';
  latency?: string;
  timestamp: string;
};
